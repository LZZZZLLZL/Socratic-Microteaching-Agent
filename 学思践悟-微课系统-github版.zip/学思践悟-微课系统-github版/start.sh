#!/usr/bin/env bash
# ==========================================================================
# 学思践悟 — 一键启动脚本（macOS）
# 支持两种模式：
#   [1] 体验版：仅启动前端界面（演示模式），1-2 分钟即可开始演示
#   [2] 完整版：自动检测并安装全部依赖（Python/Node/FFmpeg/后端包/前端包）
# ==========================================================================
set -e

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$ROOT_DIR/微课系统/backend"
FRONTEND_DIR="$ROOT_DIR/微课系统/frontend"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'

cleanup() {
  echo ""
  echo -e "${CYAN}[清理] 正在停止所有服务...${NC}"
  [ -n "$BACKEND_PID" ] && kill "$BACKEND_PID" 2>/dev/null && echo -e "${GREEN}  ✓ 后端已停止${NC}"
  [ -n "$FRONTEND_PID" ] && kill "$FRONTEND_PID" 2>/dev/null && echo -e "${GREEN}  ✓ 前端已停止${NC}"
  echo -e "${GREEN}所有服务已关闭${NC}"
  exit 0
}

trap cleanup SIGINT SIGTERM

echo -e "${CYAN}"
echo "  ╔══════════════════════════════════════╗"
echo "  ║   🍎 学思践悟 AI 多模态实训系统     ║"
echo "  ╚══════════════════════════════════════╝"
echo -e "${NC}"

# ==========================================================================
# 模式选择
# ==========================================================================
echo "  ┌─────────────────────────────────────────────┐"
echo "  │  请选择启动模式：                            │"
echo "  │                                             │"
echo "  │   [1] 体验版 · 快速演示（推荐）              │"
echo "  │       前端界面 + 真实 AI 对话，约 1-2 分钟   │"
echo "  │       点击\"演示模式\"查看全部功能            │"
echo "  │                                             │"
echo "  │   [2] 完整版 · 真实视频分析                  │"
echo "  │       自动安装 Python/FFmpeg/AI 依赖         │"
echo "  │       可上传视频进行真实分析（首次约10-20分）│"
echo "  └─────────────────────────────────────────────┘"
echo ""
read -p "  请输入 1 或 2（直接回车默认 1）：" MODE
MODE="${MODE:-1}"
echo ""

if [ "$MODE" = "2" ]; then
  echo -e "${CYAN}[完整版] 自动检测并安装全部依赖...${NC}"
  echo ""
  FULL_MODE=1
else
  echo -e "${CYAN}[体验版] 正在准备前端界面...${NC}"
  echo ""
  FULL_MODE=0
fi

# ==========================================================================
# 检测 Node.js（两种模式都需要）
# ==========================================================================
echo -e "${CYAN}[检测] Node.js...${NC}"
if command -v node &>/dev/null; then
  NODEV=$(node --version 2>&1 | sed 's/v//')
  NODEMAJOR=$(echo "$NODEV" | cut -d. -f1)
  if [ "$NODEMAJOR" -ge 18 ] 2>/dev/null; then
    echo -e "  ${GREEN}✓ Node.js ${NODEV} 已就绪${NC}"
  else
    echo -e "  ${YELLOW}⚠ Node.js 版本过低 (${NODEV})，需要 18+，尝试自动升级...${NC}"
    if command -v brew &>/dev/null; then
      brew upgrade node 2>/dev/null || brew install node
      echo -e "  ${GREEN}✓ Node.js 已升级${NC}"
    else
      echo -e "  ${RED}✗ 自动升级失败，请手动安装 Node.js 18+：https://nodejs.org/${NC}"
      exit 1
    fi
  fi
else
  echo -e "  ${YELLOW}✗ 未检测到 Node.js，尝试用 Homebrew 自动安装...${NC}"
  if command -v brew &>/dev/null; then
    brew install node
    echo -e "  ${GREEN}✓ Node.js 自动安装完成${NC}"
  else
    echo -e "  ${RED}[错误] 未找到 Homebrew，无法自动安装 Node.js${NC}"
    echo -e "  ${YELLOW}请手动安装 Node.js 18+：https://nodejs.org/${NC}"
    exit 1
  fi
fi

if ! command -v npm &>/dev/null; then
  echo -e "  ${RED}✗ npm 未找到，请重新安装 Node.js${NC}"
  exit 1
fi

# ==========================================================================
# 检测前端 npm 依赖（两种模式都需要）
# ==========================================================================
echo -e "${CYAN}[检测] 前端 npm 依赖...${NC}"
if [ ! -d "$FRONTEND_DIR/node_modules" ]; then
  echo -e "  ${YELLOW}✗ 前端依赖未安装，正在自动安装 (npm install)...${NC}"
  echo -e "  ${YELLOW}  首次安装约 3-5 分钟，请耐心等待（需联网）${NC}"
  cd "$FRONTEND_DIR"
  npm install --silent
  echo -e "  ${GREEN}✓ 前端依赖安装完成${NC}"
else
  echo -e "  ${GREEN}✓ 前端依赖已就绪${NC}"
fi

# ==========================================================================
# 体验版：前端 + 轻量 AI 对话后端
# ==========================================================================
if [ "$FULL_MODE" = "0" ]; then
  echo ""
  echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${GREEN}  体验版环境就绪，正在启动...${NC}"
  echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo ""

  # ---------- 检测 Python（轻量对话后端需要） ----------
  echo -e "${CYAN}[检测] Python...${NC}"
  TRIAL_PYTHON=""
  if [ -x "/opt/homebrew/bin/python3.11" ]; then
    TRIAL_PYTHON="/opt/homebrew/bin/python3.11"
    echo -e "  ${GREEN}✓ Python 3.11 (Homebrew) 已就绪${NC}"
  elif command -v python3 &>/dev/null; then
    TRIAL_PYTHON="python3"
    echo -e "  ${GREEN}✓ $(python3 --version 2>&1) 已就绪${NC}"
  elif command -v python &>/dev/null; then
    TRIAL_PYTHON="python"
    echo -e "  ${GREEN}✓ $(python --version 2>&1) 已就绪${NC}"
  fi

  if [ -z "$TRIAL_PYTHON" ]; then
    echo -e "  ${YELLOW}✗ 未检测到 Python，尝试用 Homebrew 自动安装...${NC}"
    if command -v brew &>/dev/null; then
      brew install python@3.11
      TRIAL_PYTHON="/opt/homebrew/bin/python3.11"
      [ -x "$TRIAL_PYTHON" ] || TRIAL_PYTHON="python3"
      echo -e "  ${GREEN}✓ Python 自动安装完成${NC}"
    else
      echo -e "  ${YELLOW}⚠ Python 安装失败，体验版将运行\"纯界面模式\"（对话为本地模拟）${NC}"
    fi
  fi

  # ---------- 安装轻量后端依赖 ----------
  if [ -n "$TRIAL_PYTHON" ]; then
    echo -e "${CYAN}[检测] 轻量对话后端依赖...${NC}"
    if ! $TRIAL_PYTHON -c "import fastapi, openai" 2>/dev/null; then
      echo -e "  ${YELLOW}✗ 轻量后端依赖未安装，正在安装 (pip install -r requirements-trial.txt)...${NC}"
      cd "$BACKEND_DIR"
      if ! $TRIAL_PYTHON -m pip install -r requirements-trial.txt; then
        echo -e "  ${YELLOW}⚠ 轻量后端依赖安装失败，体验版将运行\"纯界面模式\"（对话为本地模拟）${NC}"
        TRIAL_PYTHON=""
      else
        echo -e "  ${GREEN}✓ 轻量后端依赖安装完成${NC}"
      fi
    else
      echo -e "  ${GREEN}✓ 轻量后端依赖已就绪${NC}"
    fi
  fi

  # ---------- 启动轻量对话后端（端口 8000） ----------
  if [ -n "$TRIAL_PYTHON" ]; then
    echo -e "${CYAN}[启动] 轻量 AI 对话后端 (FastAPI :8000)...${NC}"
    cd "$BACKEND_DIR"
    TRIAL_LOG=$(mktemp)
    $TRIAL_PYTHON trial_chat_server.py >"$TRIAL_LOG" 2>&1 &
    TRIAL_PID=$!
    sleep 3
    if kill -0 "$TRIAL_PID" 2>/dev/null; then
      echo -e "  ${GREEN}✓ 对话后端已启动 (PID: $TRIAL_PID) → http://127.0.0.1:8000${NC}"
    else
      echo -e "  ${YELLOW}⚠ 对话后端启动失败（对话将回退为本地模拟）${NC}"
      TRIAL_PID=""
    fi
  fi

  # ---------- 启动前端 ----------
  echo -e "${CYAN}[启动] 前端界面 (Nuxt :3000)...${NC}"
  cd "$FRONTEND_DIR"
  npm run dev &
  FRONTEND_PID=$!
  sleep 3

  if kill -0 "$FRONTEND_PID" 2>/dev/null; then
    echo -e "${GREEN}  ✓ 前端已启动 (PID: $FRONTEND_PID) → http://localhost:3000${NC}"
  else
    echo -e "${RED}  ✗ 前端启动失败${NC}"
    [ -n "$TRIAL_PID" ] && kill "$TRIAL_PID" 2>/dev/null
    exit 1
  fi

  echo ""
  echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${GREEN}  体验版启动完成！${NC}"
  echo -e "${GREEN}  前端:  http://localhost:3000${NC}"
  echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${YELLOW}  💡 演示提示：${NC}"
  echo -e "${YELLOW}     1. 首页点击 \"演示模式\" 按钮 → 查看完整分析界面${NC}"
  echo -e "${YELLOW}     2. 分析结果中点 \"开始对话\" → 体验 AI 苏格拉底式对话${NC}"
  echo -e "${YELLOW}        （若检测到 DeepSeek Key 则为真实 AI 对话，${NC}"
  echo -e "${YELLOW}          否则自动切换为内置模拟对话）${NC}"
  echo -e "${YELLOW}     3. 点 \"导出报告\" → 下载分析报告 HTML${NC}"
  echo -e "${YELLOW}  ⚠ 体验版不做真实视频分析；如需上传视频分析，${NC}"
  echo -e "${YELLOW}     请停止后重新运行并选择\"完整版\"。${NC}"
  echo -e "${CYAN}  按 Ctrl+C 停止服务${NC}"
  echo ""
  wait
  exit 0
fi

# ==========================================================================
# ==================== 完整版：继续检测其余依赖 ====================
# ==========================================================================

# [1/6] 检查 .env（API Key）
if [ ! -f "$BACKEND_DIR/.env" ]; then
  echo -e "${YELLOW}────────────────────────────────────────${NC}"
  echo -e "${YELLOW}  ⚠ 未找到 backend/.env 文件${NC}"
  echo -e "${YELLOW}  后端需要 DEEPSEEK_API_KEY 才能启动${NC}"
  echo -e ""
  echo -e "${YELLOW}  请创建 微课系统/backend/.env 文件:${NC}"
  echo -e "${YELLOW}    echo 'DEEPSEEK_API_KEY=你的key' > 微课系统/backend/.env${NC}"
  echo -e "${YELLOW}  获取 Key: https://platform.deepseek.com/api_keys${NC}"
  echo -e "${YELLOW}────────────────────────────────────────${NC}"
  echo ""
  read -p "  是否继续启动？（演示模式仍可用） [y/N]: " -n 1 -r
  echo ""
  if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 1
  fi
fi

# [2/6] 检测 Python 3.9+
echo -e "\n${CYAN}[2/6] 检测 Python...${NC}"

PYTHON=""
if [ -x "/opt/homebrew/bin/python3.11" ]; then
  PYTHON="/opt/homebrew/bin/python3.11"
  echo -e "  ${GREEN}✓ Python 3.11 (Homebrew) 已就绪${NC}"
elif command -v python3 &>/dev/null; then
  PYTHON="python3"
  PYVER=$(python3 --version 2>&1)
  echo -e "  ${GREEN}✓ ${PYVER} 已就绪${NC}"
elif command -v python &>/dev/null; then
  PYTHON="python"
  PYVER=$(python --version 2>&1)
  echo -e "  ${GREEN}✓ ${PYVER} 已就绪${NC}"
fi

if [ -z "$PYTHON" ]; then
  echo -e "  ${YELLOW}✗ 未检测到 Python，尝试用 Homebrew 自动安装...${NC}"
  if command -v brew &>/dev/null; then
    brew install python@3.11
    PYTHON="/opt/homebrew/bin/python3.11"
    [ -x "$PYTHON" ] || PYTHON="python3"
    echo -e "  ${GREEN}✓ Python 自动安装完成${NC}"
  else
    echo -e "  ${RED}[错误] 未找到 Homebrew，无法自动安装 Python${NC}"
    echo -e "  ${YELLOW}请手动安装 Python 3.9+：https://www.python.org/downloads/${NC}"
    echo -e "  ${YELLOW}安装完成后重新双击本脚本即可。${NC}"
    exit 1
  fi
fi

# 确保 pip 可用
if ! $PYTHON -m pip --version &>/dev/null; then
  echo -e "  ${YELLOW}⚠ 未找到 pip，正在安装...${NC}"
  $PYTHON -m ensurepip --upgrade 2>/dev/null || true
  if ! $PYTHON -m pip --version &>/dev/null; then
    echo -e "  ${RED}✗ pip 安装失败，请手动安装${NC}"
    exit 1
  fi
  echo -e "  ${GREEN}✓ pip 已安装${NC}"
fi

# 激活项目虚拟环境（如果存在）
if [ -f "$BACKEND_DIR/venv/bin/activate" ]; then
  source "$BACKEND_DIR/venv/bin/activate"
  PYTHON="python"
  echo -e "  ${GREEN}✓ 已激活虚拟环境 venv${NC}"
elif [ -f "$BACKEND_DIR/.venv/bin/activate" ]; then
  source "$BACKEND_DIR/.venv/bin/activate"
  PYTHON="python"
  echo -e "  ${GREEN}✓ 已激活虚拟环境 .venv${NC}"
fi

# [4/6] 检测 FFmpeg
echo -e "\n${CYAN}[4/6] 检测 FFmpeg...${NC}"

if command -v ffmpeg &>/dev/null; then
  echo -e "  ${GREEN}✓ FFmpeg $(ffmpeg -version 2>&1 | head -1 | grep -oE '[0-9]+\.[0-9]+') 已就绪${NC}"
else
  echo -e "  ${YELLOW}✗ 未检测到 FFmpeg，尝试用 Homebrew 自动安装...${NC}"
  if command -v brew &>/dev/null; then
    brew install ffmpeg
    echo -e "  ${GREEN}✓ FFmpeg 自动安装完成${NC}"
  else
    echo -e "  ${YELLOW}⚠ 未找到 Homebrew，无法自动安装 FFmpeg${NC}"
    echo -e "  ${YELLOW}  提示：FFmpeg 仅真实视频分析需要，演示模式不受影响${NC}"
    echo -e "  ${YELLOW}  如需安装：brew install ffmpeg 或 https://ffmpeg.org/download.html${NC}"
  fi
fi

# [5/6] 检测后端 Python 依赖
echo -e "\n${CYAN}[5/6] 检测后端 Python 依赖...${NC}"

cd "$BACKEND_DIR"

if ! $PYTHON -c "import fastapi" 2>/dev/null; then
  echo -e "  ${YELLOW}✗ 后端依赖未安装，正在自动安装 (pip install -r requirements.txt)...${NC}"
  echo -e "  ${YELLOW}  首次安装约 5-10 分钟，请耐心等待（需联网）${NC}"
  $PYTHON -m pip install -r requirements.txt
  echo -e "  ${GREEN}✓ 后端依赖安装完成${NC}"
else
  echo -e "  ${GREEN}✓ 后端依赖已就绪${NC}"
fi

# ==========================================================================
# 环境就绪，启动系统（完整版）
# ==========================================================================
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  环境检查完毕，正在启动系统...${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# 启动后端
echo -e "${CYAN}[1/2] 启动后端 (FastAPI :8000)...${NC}"

cd "$BACKEND_DIR"
BACKEND_LOG=$(mktemp)
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 $PYTHON main.py >"$BACKEND_LOG" 2>&1 &
BACKEND_PID=$!

echo -n "  等待后端就绪"
HEALTHY=0
for i in $(seq 1 60); do
  sleep 2
  if ! kill -0 "$BACKEND_PID" 2>/dev/null; then
    echo ""
    echo -e "${RED}  ✗ 后端进程意外退出，错误信息:${NC}"
    cat "$BACKEND_LOG" | tail -20
    rm -f "$BACKEND_LOG"
    exit 1
  fi
  if curl -s http://127.0.0.1:8000/docs -o /dev/null 2>/dev/null; then
    HEALTHY=1
    echo " ✓"
    break
  fi
  echo -n "."
done

if [ "$HEALTHY" -eq 1 ]; then
  echo -e "${GREEN}  ✓ 后端已启动 (PID: $BACKEND_PID) → http://127.0.0.1:8000${NC}"
else
  echo ""
  echo -e "${YELLOW}  ⚠ 后端启动超时（仍在加载模型），进程存活中${NC}"
  echo -e "${YELLOW}  请等待模型加载完成后刷新页面${NC}"
fi

# 启动前端
echo -e "${CYAN}[2/2] 启动前端 (Nuxt :3000)...${NC}"

cd "$FRONTEND_DIR"
npm run dev &
FRONTEND_PID=$!
sleep 3

if kill -0 "$FRONTEND_PID" 2>/dev/null; then
  echo -e "${GREEN}  ✓ 前端已启动 (PID: $FRONTEND_PID) → http://localhost:3000${NC}"
else
  echo -e "${RED}  ✗ 前端启动失败${NC}"
  kill "$BACKEND_PID" 2>/dev/null
  exit 1
fi

# 完成
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  🚀 系统启动完成！${NC}"
echo -e "${GREEN}  前端:  http://localhost:3000${NC}"
echo -e "${GREEN}  后端:  http://127.0.0.1:8000${NC}"
echo -e "${GREEN}  API:   http://127.0.0.1:8000/docs${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}  按 Ctrl+C 停止所有服务${NC}"
echo ""

rm -f "$BACKEND_LOG"
wait