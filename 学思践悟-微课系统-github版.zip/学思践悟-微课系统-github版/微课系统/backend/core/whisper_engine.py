import whisper
import torch
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()


class TranscriptionEngine:
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"[Whisper] 引擎已就绪 | 运行设备: {self.device}")

        # Whisper base 模型，中文断句和标点能力较弱
        self.model = whisper.load_model("base", device=self.device)

        # 复用 DeepSeek 做标点还原（轻量文本处理，延迟很低）
        self.llm_client = OpenAI(
            api_key=os.getenv("DEEPSEEK_API_KEY"),
            base_url="https://api.deepseek.com"
        )

    def _restore_punctuation(self, text: str) -> str:
        """用 DeepSeek 给无标点中文文本恢复标点符号和自然断句"""
        if not text.strip():
            return text

        try:
            response = self.llm_client.chat.completions.create(
                model="deepseek-chat",
                messages=[{
                    "role": "system",
                    "content": (
                        "你是一个中文文本标点还原工具。请为以下无标点的中文文本添加正确的标点符号"
                        "（。，！？；：、），并进行合理的分段。\n"
                        "规则：\n"
                        "1. 只添加标点和换行，不修改、不增删任何字词\n"
                        "2. 根据语义判断句间停顿：完整句子结束用句号，句中停顿用逗号\n"
                        "3. 直接返回带标点的文本，不要加任何解释"
                    )
                }, {
                    "role": "user",
                    "content": text
                }],
                temperature=0.1,
                max_tokens=4096
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            print(f"[Whisper] 标点还原失败，使用原始文本: {e}")
            return text

    def transcribe(self, file_path: str, add_punctuation: bool = True):
        """
        利用 GPU 进行语音转文字

        Args:
            file_path: 音频文件路径
            add_punctuation: 是否调用 DeepSeek 做标点还原，默认开启

        Returns:
            dict: {
                "full_text": "完整转写文本",
                "segments": [{"start": 0.0, "end": 5.2, "text": "各位同学好..."}, ...]
            }
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"找不到音频文件: {file_path}")

        print(f"[Whisper] GPU 加速转写中: {os.path.basename(file_path)}")

        result = self.model.transcribe(
            file_path,
            fp16=False,
            language="zh",
        )

        # 提取带时间戳的分段信息
        raw_segments = result.get("segments", [])
        timed_segments = []
        for seg in raw_segments:
            timed_segments.append({
                "start": round(seg["start"], 1),
                "end": round(seg["end"], 1),
                "text": seg["text"].strip()
            })

        # 拼接完整文本用于标点还原
        if timed_segments:
            raw_text = "\n".join(seg["text"] for seg in timed_segments)
        else:
            raw_text = result["text"].strip()

        # 标点还原
        full_text = raw_text
        if add_punctuation and raw_text:
            print("[Whisper] 标点还原中（DeepSeek）...")
            full_text = self._restore_punctuation(raw_text)

        return {
            "full_text": full_text,
            "segments": timed_segments
        }


# 实例化，方便 main.py 直接调用
transcriber = TranscriptionEngine()
