import os
import json
import time
import uuid
import subprocess
import shutil
import uvicorn
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from core.whisper_engine import transcriber
from core.agent_logic import ai_assistant
from core.rag_engine import rag_engine
from core.vision_engine import vision_analyzer

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = FastAPI(title="学思践悟 AI 多模态实训后端")

# --- 静态文件服务（挂载在 /static 下，不会劫持 /api/*）---
frontend_dir = os.path.join(os.path.dirname(BASE_DIR), "frontend")
if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="frontend")

# --- 初始化 ---
def init_standards():
    standard_files = [
        "it_standard.txt",
        "微课大赛_评价标准.txt",
    ]
    possible_dirs = [
        os.path.join(BASE_DIR, "data"),
        os.path.join(os.path.dirname(BASE_DIR), "data"),
    ]
    loaded_any = False
    for fname in standard_files:
        for d in possible_dirs:
            path = os.path.join(d, fname)
            if os.path.exists(path):
                rag_engine.load_local_standards(path)
                print(f"RAG ok: {path}")
                loaded_any = True
                break  # 找到该文件就停止搜索目录
    if not loaded_any:
        print("cannot find any standard files")

init_standards()

# --- CORS ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

TEMP_DIR = os.path.join(BASE_DIR, "data", "temp_uploads")
VIDEO_DIR = os.path.join(BASE_DIR, "data", "videos")
os.makedirs(TEMP_DIR, exist_ok=True)
os.makedirs(VIDEO_DIR, exist_ok=True)


def cleanup_temp_files(max_age_seconds: int = 3600):
    """清理临时目录中超过指定时间的残留文件"""
    for directory in [TEMP_DIR, VIDEO_DIR]:
        if not os.path.exists(directory):
            continue
        now = time.time()
        cleaned = 0
        for fname in os.listdir(directory):
            fpath = os.path.join(directory, fname)
            try:
                if os.path.isfile(fpath) and (now - os.path.getmtime(fpath)) > max_age_seconds:
                    os.remove(fpath)
                    cleaned += 1
            except OSError:
                pass
        if cleaned:
            print(f"[Cleanup] 已清理 {directory} 中 {cleaned} 个过期文件")


# 启动时清理上次遗留的临时文件
cleanup_temp_files(max_age_seconds=60)


def has_audio_stream(video_path: str) -> bool:
    """用 ffprobe 检测视频是否包含音频轨道"""
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a",
         "-show_entries", "stream=codec_type", "-of", "csv=p=0", video_path],
        capture_output=True, text=True
    )
    return bool(r.stdout.strip())


def extract_audio(video_path: str, audio_path: str):
    """用 ffmpeg 提取音频，Whisper 直接处理音频比视频快得多"""
    subprocess.run(
        ["ffmpeg", "-i", video_path, "-vn", "-acodec", "pcm_s16le",
         "-ar", "16000", "-ac", "1", "-y", audio_path],
        capture_output=True, check=True
    )


# --- 分析接口（SSE 流式返回进度）---
@app.post("/api/v1/analyze")
async def analyze_video(file: UploadFile = File(...)):
    file_id = str(uuid.uuid4())[:8]
    ext = os.path.splitext(file.filename or "video.mp4")[1] or ".mp4"
    video_path = os.path.join(TEMP_DIR, f"{file_id}{ext}")
    audio_path = os.path.join(TEMP_DIR, f"{file_id}.wav")
    saved_video_path = os.path.join(VIDEO_DIR, f"{file_id}{ext}")

    with open(video_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    async def generate():
        try:
            # 1. 检测并提取音频 (0-15%)
            yield f"data: {json.dumps({'p': 5, 's': '检测视频音频轨道...'})}\n\n"
            if has_audio_stream(video_path):
                extract_audio(video_path, audio_path)
                yield f"data: {json.dumps({'p': 15, 's': '音频提取完成'})}\n\n"

                # 2. 语音转写 (15-45%) — 返回 {full_text, segments}
                yield f"data: {json.dumps({'p': 18, 's': '语音转写中（Whisper GPU 加速）...'})}\n\n"
                transcribe_result = transcriber.transcribe(audio_path)
                text_result = transcribe_result["full_text"]
                whisper_segments = transcribe_result["segments"]
                yield f"data: {json.dumps({'p': 45, 's': '语音转写完成'})}\n\n"
            else:
                yield f"data: {json.dumps({'p': 15, 's': '视频无音频轨道，跳过语音转写'})}\n\n"
                text_result = ""
                whisper_segments = []

            # 3. 视觉分析 (45-75%)
            yield f"data: {json.dumps({'p': 48, 's': '视觉动作分析中（YOLOv8 GPU 加速）...'})}\n\n"
            vision_data = vision_analyzer.analyze_video(video_path)
            yield f"data: {json.dumps({'p': 70, 's': '视觉分析完成'})}\n\n"

            # 4. RAG 检索 (75-85%)
            yield f"data: {json.dumps({'p': 73, 's': '课标检索中...'})}\n\n"
            if text_result:
                related_standards = rag_engine.query_related_standard(text_result, top_k=2)
            else:
                related_standards = []
            yield f"data: {json.dumps({'p': 85, 's': '课标检索完成'})}\n\n"

            # 5. AI 点评 (85-100%)
            teaching_content = text_result if text_result else "（未检测到语音内容）"
            gesture_level = vision_data.get('gesture_level', '—')
            hand_balance = vision_data.get('hand_balance', 50)
            bal_desc = '均衡' if hand_balance >= 40 else ('偏侧' if hand_balance >= 20 else '单侧')
            both_desc = '较多' if vision_data.get('both_hands_ratio', 0) > 0.3 else '较少'
            gesture_data = f"""【教态数据（仅后台参考，不要在分析中主动提及）】
- 背对学生时间占比：{round(vision_data['back_ratio'] * 100, 1)}%
- 手势频次：{vision_data['gesture_intensity']} 次
- 手势幅度评级：{gesture_level}
- 左右手均衡度：{bal_desc}（左手使用占比 {hand_balance}%）
- 双手并用：{both_desc}
- 位移幅度：{vision_data['movement_range']}
- 课堂位移状态：{'站位灵活' if not vision_data['is_stiff'] else '站位较为固定'}
- 视频总时长：{vision_data['total_duration']} 秒
"""
            session_id = str(uuid.uuid4())
            ai_assistant.init_chat_session(session_id, teaching_content, gesture_data, related_standards)

            yield f"data: {json.dumps({'p': 88, 's': 'AI 深度点评中...'})}\n\n"
            full_feedback = ""
            for chunk in ai_assistant.chat_stream(session_id):
                full_feedback += chunk

            # 5b. 多维评分卡 (88-95%)
            yield f"data: {json.dumps({'p': 92, 's': '生成多维度评分卡...'})}\n\n"
            scoring_card = ai_assistant.get_scoring_card(teaching_content)
            yield f"data: {json.dumps({'p': 100, 's': '分析完成'})}\n\n"

            # 6. 构建统一时间轴：合并 Whisper 分段 + 视觉事件
            timeline = _build_timeline(whisper_segments, vision_data.get("timeline", []))

            # 7. 持久化视频（供前端播放器回放）
            shutil.copy2(video_path, saved_video_path)
            ai_assistant.sessions_meta.setdefault(session_id, {})["video_path"] = saved_video_path

            # 发送最终结果
            result = {
                "session_id": session_id,
                "transcription": text_result,
                "vision_analysis": vision_data,
                "socratic_feedback": full_feedback,
                "referenced_standards": related_standards,
                "timeline": timeline,
                "video_url": f"/api/v1/video/{file_id}{ext}",
                "scoring_card": scoring_card.get("scores", [])
            }
            yield f"data: {json.dumps({'done': True, 'result': result})}\n\n"

        except Exception as e:
            print(f"error: {str(e)}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
        finally:
            for p in [video_path, audio_path]:
                if os.path.exists(p):
                    os.remove(p)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        }
    )


# --- 多轮对话 SSE 接口 ---
@app.post("/api/v1/chat")
async def chat_stream(data: dict):
    session_id = data.get("session_id")
    user_message = data.get("message", "")

    if not session_id:
        return {"status": "error", "message": "no session_id"}

    def generate():
        try:
            for text_chunk in ai_assistant.chat_stream(session_id, user_message):
                yield f"data: {json.dumps({'text': text_chunk})}\n\n"
            yield f"data: {json.dumps({'done': True})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        }
    )


def _build_timeline(whisper_segments: list, vision_timeline: list) -> list:
    """
    将 Whisper 分段和视觉事件合并为统一时间轴。
    返回: [{"start": 0.0, "end": 5.2, "text": "...", "back": False, "gesture": 3}, ...]
    """
    if not whisper_segments:
        return []

    # 将视觉数据按时间索引，方便快速查找
    vision_by_time = {}
    for evt in vision_timeline:
        t = evt["t"]
        vision_by_time[t] = evt

    timeline = []
    for seg in whisper_segments:
        seg_start = seg["start"]
        seg_end = seg["end"]
        seg_mid = (seg_start + seg_end) / 2

        # 查找该时间段内最接近的视觉采样点
        back_count = 0
        gesture_count = 0
        total_vision_samples = 0

        for evt in vision_timeline:
            if seg_start <= evt["t"] <= seg_end:
                total_vision_samples += 1
                if evt["back"]:
                    back_count += 1
                if evt["gesture"]:
                    gesture_count += 1

        # 如果段内没有视觉采样点，用最近的一个采样点
        if total_vision_samples == 0 and vision_timeline:
            closest = min(vision_timeline, key=lambda e: abs(e["t"] - seg_mid))
            total_vision_samples = 1
            back_count = 1 if closest["back"] else 0
            gesture_count = 1 if closest["gesture"] else 0

        timeline.append({
            "start": seg_start,
            "end": seg_end,
            "text": seg["text"],
            "back": back_count > total_vision_samples * 0.5,  # 超过一半时间背对
            "gesture": gesture_count
        })

    return timeline


# --- 视频文件服务 ---
@app.get("/api/v1/video/{filename}")
async def serve_video(filename: str):
    """提供已分析视频的播放服务"""
    video_path = os.path.join(VIDEO_DIR, filename)
    if not os.path.exists(video_path):
        return {"status": "error", "message": "视频不存在或已过期"}
    return FileResponse(video_path, media_type="video/mp4")


# --- 清除对话历史 ---
@app.post("/api/v1/chat/clear")
async def clear_chat(data: dict):
    session_id = data.get("session_id")
    if not session_id:
        return {"status": "error", "message": "no session_id"}
    ai_assistant.clear_session(session_id)
    return {"status": "ok", "message": f"session {session_id} cleared"}


# ── 前端页面路由（放在最后，确保不覆盖 API 路由）──
if os.path.exists(frontend_dir):
    @app.get("/")
    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str = ""):
        file_path = os.path.join(frontend_dir, full_path or "index.html")
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        fallback = os.path.join(frontend_dir, "index.html")
        if os.path.exists(fallback):
            return FileResponse(fallback)
        return {"status": "error", "message": "not found"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
