# ==========================================================================
# 学思践悟 — 体验版轻量对话后端
# 仅依赖 fastapi + openai + python-dotenv，无需 Whisper/YOLOv8 等重型 AI 模型
# 提供 /api/v1/chat 和 /api/v1/chat/clear 接口，供体验版前端对话使用
# 内部使用真实 DeepSeek API 进行苏格拉底式对话
# ==========================================================================

import os
import json
import sys
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

# 将 backend 目录加入 sys.path，以便 import core.agent_logic
BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

from core.agent_logic import ai_assistant
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="学思践悟 体验版对话后端")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==========================================================================
# 演示教学文稿（与前端 demoData.ts 保持一致）
# ==========================================================================
DEMO_TRANSCRIPTION = (
    '各位同学好，今天我们来学习信息技术的基本概念。'
    '首先，什么是信息？信息是客观世界各种事物的特征的反映，'
    '它可以通过数据、图像、声音等方式来表现。'
    '接下来，我们一起来看看信息技术的定义。'
    '信息技术是指在计算机和通信技术的支持下，用于获取、加工、存储、'
    '传输和展示信息的所有技术的总称。'
)

DEMO_STANDARDS = [
    '《中小学信息技术课程标准》指出：信息技术课程旨在培养学生的信息素养，包括信息的获取、加工、表达和交流的能力。',
    '教学应注重理论与实践相结合，引导学生在真实情境中理解和应用信息技术。',
]

DEMO_GESTURE = """【教态数据（仅后台参考，不要在分析中主动提及）】
- 背对学生时间占比：12.0%
- 手势频次：28 次
- 手势幅度评级：活跃
- 左右手均衡度：偏侧（左手使用占比 65%）
- 双手并用：较多
- 位移幅度：156.3
- 课堂位移状态：站位灵活
- 视频总时长：180 秒
"""

# ==========================================================================
# 初始化演示对话 session
# ==========================================================================
@app.on_event("startup")
async def init_demo():
    """启动时自动初始化 demo session"""
    key = os.getenv("DEEPSEEK_API_KEY", "")
    if not key or key == "your_deepseek_api_key_here":
        print("⚠ [体验版] 未配置 DEEPSEEK_API_KEY，对话将不可用（前端会回退到本地模拟）")
        return
    try:
        ai_assistant.init_chat_session(
            "demo-session-001",
            DEMO_TRANSCRIPTION,
            DEMO_GESTURE,
            DEMO_STANDARDS,
        )
        print("✓ [体验版] 演示对话 session 已初始化，真实 DeepSeek 对话就绪")
    except Exception as e:
        print(f"✗ [体验版] 演示对话初始化失败: {e}")


# ==========================================================================
# POST /api/v1/chat（SSE 流式）
# ==========================================================================
@app.post("/api/v1/chat")
async def chat_stream(data: dict):
    session_id = data.get("session_id")
    user_message = data.get("message", "")

    if not session_id:
        return {"status": "error", "message": "no session_id"}

    # 检查 API Key 是否可用
    key = os.getenv("DEEPSEEK_API_KEY", "")
    if not key or key == "your_deepseek_api_key_here":
        return StreamingResponse(
            _error_stream("未配置 DEEPSEEK_API_KEY，请检查 .env 文件"),
            media_type="text/event-stream",
        )

    # 对于未初始化的 session 自动初始化（兼容非 demo 的会话）
    if session_id not in ai_assistant.sessions:
        try:
            ai_assistant.init_chat_session(
                session_id, DEMO_TRANSCRIPTION, DEMO_GESTURE, DEMO_STANDARDS
            )
        except Exception as e:
            return StreamingResponse(
                _error_stream(f"初始化对话失败: {e}"),
                media_type="text/event-stream",
            )

    def generate():
        try:
            for text_chunk in ai_assistant.chat_stream(session_id, user_message):
                if text_chunk is None:
                    continue
                yield f"data: {json.dumps({'text': text_chunk})}\n\n"
            yield f"data: {json.dumps({'done': True})}\n\n"
        except Exception as e:
            print(f"[TrialServer] Chat error: {e}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ==========================================================================
# POST /api/v1/chat/clear
# ==========================================================================
@app.post("/api/v1/chat/clear")
async def clear_chat(data: dict):
    session_id = data.get("session_id")
    if not session_id:
        return {"status": "error", "message": "no session_id"}
    ai_assistant.clear_session(session_id)
    return {"status": "ok", "message": f"session {session_id} cleared"}


# ==========================================================================
# 健康检查
# ==========================================================================
@app.get("/api/v1/health")
async def health():
    key = os.getenv("DEEPSEEK_API_KEY", "")
    has_key = bool(key) and key != "your_deepseek_api_key_here"
    return {
        "status": "ok",
        "version": "trial",
        "api_key_configured": has_key,
    }


# ==========================================================================
# 错误流辅助函数
# ==========================================================================
def _error_stream(msg: str):
    def gen():
        yield f"data: {json.dumps({'error': msg})}\n\n"
        yield f"data: {json.dumps({'done': True})}\n\n"

    return gen()


# ==========================================================================
# 入口
# ==========================================================================
if __name__ == "__main__":
    port = int(os.getenv("TRIAL_PORT", "8000"))
    print(f"🌐 学思践悟 体验版对话后端 → http://127.0.0.1:{port}")
    uvicorn.run("trial_chat_server:app", host="127.0.0.1", port=port, reload=False)