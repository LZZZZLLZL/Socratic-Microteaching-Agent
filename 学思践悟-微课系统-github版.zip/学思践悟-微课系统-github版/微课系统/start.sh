#!/bin/bash
set -e

# ============================================
#  学思践悟 AI 多模态实训系统 启动器
# ============================================

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

cleanup() {
    echo ""
    echo -e "${YELLOW}正在关闭服务...${NC}"
    [ -n "$BACKEND_PID" ] && kill "$BACKEND_PID" 2>/dev/null
    [ -n "$FRONTEND_PID" ] && kill "$FRONTEND_PID" 2>/dev/null
    echo -e "${GREEN}服务已停止${NC}"
    exit 0
}
trap cleanup SIGINT SIGTERM

echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}  学思践悟 AI 多模态实训系统${NC}"
echo -e "${CYAN}============================================${NC}"
echo ""

# --- 检查依赖 ---
echo -e "${YELLOW}[1/4] 检查环境...${NC}"

# Python
PYTHON=$(which python3 || which python)
if [ -z "$PYTHON" ]; then
    echo -e "${RED}未找到 Python，请先安装 Python 3.9+${NC}"
    exit 1
fi
echo -e "  Python: ${GREEN}$($PYTHON --version)${NC}"

# ffmpeg
if ! command -v ffmpeg &>/dev/null; then
    echo -e "${RED}未找到 ffmpeg，请先安装: brew install ffmpeg${NC}"
    exit 1
fi
echo -e "  ffmpeg: ${GREEN}$(ffmpeg -version 2>&1 | head -1 | cut -d' ' -f3)${NC}"

# Node
if ! command -v node &>/dev/null; then
    echo -e "${RED}未找到 Node.js，请先安装${NC}"
    exit 1
fi
echo -e "  Node:   ${GREEN}$(node --version)${NC}"

# --- 安装后端依赖 ---
echo ""
echo -e "${YELLOW}[2/4] 检查后端依赖...${NC}"
cd "$BACKEND_DIR"
if ! python3 -c "import fastapi" 2>/dev/null; then
    echo "  正在安装后端依赖..."
    pip install -r requirements.txt -q
fi
echo -e "  后端依赖: ${GREEN}OK${NC}"

# --- 安装前端依赖 ---
echo ""
echo -e "${YELLOW}[3/4] 检查前端依赖...${NC}"
cd "$FRONTEND_DIR"
if [ ! -d "node_modules" ]; then
    echo "  正在安装前端依赖..."
    npm install --silent
fi
echo -e "  前端依赖: ${GREEN}OK${NC}"

# --- 检查 .env ---
if [ ! -f "$BACKEND_DIR/.env" ]; then
    echo ""
    echo -e "${YELLOW}[!] 未找到 backend/.env，请创建并设置 DEEPSEEK_API_KEY${NC}"
    echo "  echo 'DEEPSEEK_API_KEY=sk-xxx' > backend/.env"
fi

# --- 启动服务 ---
echo ""
echo -e "${YELLOW}[4/4] 启动服务...${NC}"

# 后端
cd "$BACKEND_DIR"
echo -e "  启动后端: ${GREEN}http://127.0.0.1:8000${NC}"
python3 main.py &
BACKEND_PID=$!

# 前端
cd "$FRONTEND_DIR"
echo -e "  启动前端: ${GREEN}http://localhost:3000${NC}"
npm run dev &
FRONTEND_PID=$!

echo ""
echo -e "${CYAN}============================================${NC}"
echo -e "${GREEN}  系统已启动!${NC}"
echo -e "  前端: ${CYAN}http://localhost:3000${NC}"
echo -e "  后端: ${CYAN}http://127.0.0.1:8000${NC}"
echo -e "  按 ${RED}Ctrl+C${NC} 停止所有服务"
echo -e "${CYAN}============================================${NC}"

wait
