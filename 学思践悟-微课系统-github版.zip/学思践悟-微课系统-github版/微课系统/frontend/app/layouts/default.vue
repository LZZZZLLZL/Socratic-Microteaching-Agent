<template>
  <div class="layout">
    <!-- Skip to content -->
    <a href="#main-content" class="skip-to-content">跳到主要内容</a>

    <!-- Header -->
    <header class="header" role="banner">
      <div class="header-content">
        <NuxtLink to="/" class="logo" aria-label="学思践悟 首页">
          <svg class="logo-icon" viewBox="0 0 32 32" fill="none" aria-hidden="true">
            <rect width="32" height="32" rx="8" fill="var(--accent-blue)" />
            <text x="16" y="22" text-anchor="middle" font-size="18" font-weight="700" fill="white">学</text>
          </svg>
          <span class="logo-text">学思践悟</span>
        </NuxtLink>
        <nav class="nav" aria-label="主导航">
          <NuxtLink to="/" class="nav-link" :class="{ active: route.path === '/' }">
            视频分析
          </NuxtLink>
          <NuxtLink
            v-if="sessionId"
            :to="`/chat?session=${sessionId}`"
            class="nav-link"
            :class="{ active: route.path === '/chat' }"
          >
            苏格拉底对话
          </NuxtLink>
        </nav>
      </div>
    </header>

    <!-- Main content -->
    <main id="main-content" class="main" role="main" tabindex="-1">
      <slot />
    </main>

    <!-- Footer -->
    <footer class="footer" role="contentinfo">
      <div class="footer-content">
        <span>学思践悟 AI 多模态实训系统</span>
        <span class="footer-divider">·</span>
        <span>仅用于教学研究，AI 点评仅供参考</span>
      </div>
    </footer>
  </div>
</template>

<script setup lang="ts">
const route = useRoute()

// 响应式监听路由和 query 变化
const sessionId = computed(() => (route.query.session as string) || '')
</script>

<style scoped>
.layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* --- Header --- */
.header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: rgba(15, 15, 15, 0.92);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--border-subtle);
}

.header-content {
  max-width: var(--content-wide);
  margin: 0 auto;
  padding: 0 var(--space-6);
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

/* --- Logo --- */
.logo {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  color: var(--text-primary);
  font-weight: var(--font-semibold);
  font-size: var(--text-lg);
  text-decoration: none;
}

.logo:hover {
  color: var(--text-primary);
}

.logo-icon {
  width: 32px;
  height: 32px;
  flex-shrink: 0;
}

/* --- Nav --- */
.nav {
  display: flex;
  gap: var(--space-2);
}

.nav-link {
  padding: var(--space-2) var(--space-4);
  border-radius: var(--radius-md);
  color: var(--text-secondary);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  text-decoration: none;
  transition: all var(--transition-fast) var(--ease-out);
}

.nav-link:hover {
  color: var(--text-primary);
  background: var(--bg-card);
}

.nav-link.active {
  color: var(--accent-blue);
  background: var(--accent-blue-subtle);
}

/* --- Main --- */
.main {
  flex: 1;
}

/* --- Footer --- */
.footer {
  border-top: 1px solid var(--border-subtle);
  padding: var(--space-6) var(--space-6);
  background: var(--bg-dark);
}

.footer-content {
  max-width: var(--content-wide);
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  font-size: var(--text-xs);
  color: var(--text-muted);
}

.footer-divider {
  color: var(--border-default);
}

/* --- Responsive --- */
@media (max-width: 640px) {
  .header-content {
    padding: 0 var(--space-4);
  }

  .logo-text {
    font-size: var(--text-md);
  }

  .nav-link {
    padding: var(--space-2) var(--space-3);
    font-size: var(--text-xs);
  }

  .footer-content {
    flex-direction: column;
    gap: var(--space-1);
  }
}
</style>
