// ==========================================================================
// 学思践悟 — Analysis Composable
// ==========================================================================
import type { AnalysisResult } from '~/types'
import { DEMO_STEPS, DEMO_RESULT } from '~/data/demoData'

export function useAnalysis() {
  const selectedFile = ref<File | null>(null)
  const analyzing = ref(false)
  const progress = ref(0)
  const statusText = ref('')
  const result = ref<AnalysisResult | null>(null)
  const sessionId = ref('')

  // --- File handling ---
  const handleFileChange = (rawFile: File) => {
    selectedFile.value = rawFile
  }

  // --- SSE stream reader with line buffering ---
  const readSSEStream = async (
    response: Response,
    onEvent: (data: Record<string, any>) => void
  ) => {
    const reader = response.body?.getReader()
    if (!reader) throw new Error('无法读取响应流')

    const decoder = new TextDecoder()
    let buffer = ''

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split('\n')
      // 最后一行可能不完整，保留到下次
      buffer = lines.pop() || ''

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const data = JSON.parse(line.slice(6))
            onEvent(data)
          } catch {
            // 非 JSON 行，跳过
          }
        }
      }
    }
  }

  // --- Real analysis via SSE ---
  const startAnalysis = async () => {
    if (!selectedFile.value) {
      ElMessage.warning('请先选择视频文件')
      return
    }

    analyzing.value = true
    progress.value = 0
    statusText.value = '准备上传...'
    result.value = null

    const formData = new FormData()
    formData.append('file', selectedFile.value)

    try {
      const response = await fetch('/api/v1/analyze', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`服务器响应异常 (${response.status})`)
      }

      await readSSEStream(response, (data) => {
        if (data.error) {
          ElMessage.error(data.error)
          return
        }

        if (data.p !== undefined) {
          progress.value = data.p
          statusText.value = data.s
        }

        if (data.done && data.result) {
          result.value = data.result
          sessionId.value = data.result.session_id
        }
      })
    } catch (error) {
      const msg = error instanceof Error ? error.message : '分析失败，请重试'
      ElMessage.error(msg)
      console.error('Analysis error:', error)
    } finally {
      analyzing.value = false
    }
  }

  // --- Demo mode ---
  const startDemo = () => {
    analyzing.value = true
    progress.value = 0
    statusText.value = '模拟演示模式...'

    let i = 0
    const interval = setInterval(() => {
      if (i < DEMO_STEPS.length) {
        progress.value = DEMO_STEPS[i].p
        statusText.value = DEMO_STEPS[i].s
        i++
      } else {
        clearInterval(interval)
        analyzing.value = false
        result.value = DEMO_RESULT
        sessionId.value = DEMO_RESULT.session_id
      }
    }, 400)
  }

  // --- Reset ---
  const reset = () => {
    selectedFile.value = null
    result.value = null
    progress.value = 0
    statusText.value = ''
  }

  return {
    analyzing,
    progress,
    statusText,
    result,
    sessionId,
    handleFileChange,
    startAnalysis,
    startDemo,
    reset,
  }
}
