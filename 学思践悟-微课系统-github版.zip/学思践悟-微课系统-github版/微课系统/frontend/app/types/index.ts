// ==========================================================================
// 学思践悟 — Type Definitions
// ==========================================================================

/** 时间轴分段 */
export interface TimelineSegment {
  start: number
  end: number
  text: string
  back: boolean
  gesture: number
}

/** 教态预警 */
export interface VisionAlert {
  level: 'error' | 'warning' | 'info' | 'success'
  msg: string
}

/** 教态分析数据 */
export interface VisionAnalysis {
  back_ratio: number
  gesture_intensity: number
  gesture_level: string
  hand_balance: number
  both_hands_ratio: number
  is_stiff: boolean
  movement_range: number
  total_duration: number
  timeline: VisionTimelineEvent[]
  alerts: VisionAlert[]
}

/** 视觉时间轴采样点 */
export interface VisionTimelineEvent {
  t: number
  back: boolean
  gesture: boolean
}

/** 评分维度 */
export interface ScoreItem {
  name: string
  score: number
  comment: string
}

/** 分析结果 */
export interface AnalysisResult {
  session_id: string
  transcription: string
  vision_analysis: VisionAnalysis
  socratic_feedback: string
  referenced_standards: string[]
  timeline: TimelineSegment[]
  video_url: string
  scoring_card: ScoreItem[]
}

/** 聊天消息 */
export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

/** SSE 进度事件 */
export interface SSEProgress {
  p: number
  s: string
}

/** SSE 完成事件 */
export interface SSEDone {
  done: true
  result: AnalysisResult
}

/** SSE 错误事件 */
export interface SSEError {
  error: string
}

/** SSE 流式文本 */
export interface SSEText {
  text: string
  done?: boolean
}

export type SSEEvent = SSEProgress | SSEDone | SSEError | SSEText
