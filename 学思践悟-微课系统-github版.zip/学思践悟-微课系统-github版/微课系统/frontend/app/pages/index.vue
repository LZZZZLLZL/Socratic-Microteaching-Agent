<template>
  <div class="page">
    <div class="container">
      <header class="page-header">
        <h1 class="title">微课视频分析</h1>
        <p class="subtitle">上传您的微课视频，AI 将提供苏格拉底式点评</p>
      </header>

      <!-- 上传区域 -->
      <VideoUploader
        :analyzing="analyzing"
        :has-result="!!result"
        @file-change="handleFileChange"
        @start-analysis="startAnalysis"
        @start-demo="startDemo"
      />

      <!-- 分析进度 -->
      <AnalysisProgress
        :analyzing="analyzing"
        :progress="progress"
        :status-text="statusText"
      />

      <!-- 分析结果 -->
      <div v-if="result" class="result-section">
        <VideoTimeline
          :video-url="result.video_url"
          :timeline="result.timeline"
          :duration="result.vision_analysis?.total_duration"
        />

        <TranscriptionCard :text="result.transcription" />

        <StandardsCard :standards="result.referenced_standards" />

        <FeedbackCard
          :feedback="result.socratic_feedback"
          :session-id="result.session_id"
          @go-chat="goToChat"
          @export-report="exportReport"
          @reset="reset"
        />

        <ScoringCard :scores="result.scoring_card" />

        <VisionAlerts :alerts="result.vision_analysis?.alerts || []" />

        <VisionData :vision-data="result.vision_analysis" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useAnalysis } from '~/composables/useAnalysis'
import { useReportExport } from '~/composables/useReportExport'

const router = useRouter()

const {
  analyzing,
  progress,
  statusText,
  result,
  sessionId,
  handleFileChange,
  startAnalysis,
  startDemo,
  reset,
} = useAnalysis()

const { exportReport: doExport } = useReportExport()

const exportReport = () => {
  if (result.value) {
    doExport(result.value)
    ElMessage.success('报告已下载')
  }
}

const goToChat = () => {
  router.push(`/chat?session=${sessionId.value}`)
}
</script>

<style scoped>
.page {
  padding: var(--space-10) 0;
}

.container {
  max-width: var(--content-max-width);
  margin: 0 auto;
  padding: 0 var(--space-6);
}

.page-header {
  text-align: center;
  margin-bottom: var(--space-10);
}

.title {
  font-size: var(--text-3xl);
  font-weight: var(--font-semibold);
  margin-bottom: var(--space-2);
  color: var(--text-primary);
  letter-spacing: var(--tracking-tight);
}

.subtitle {
  color: var(--text-secondary);
  font-size: var(--text-md);
}

.result-section {
  display: flex;
  flex-direction: column;
  gap: var(--space-6);
  margin-top: var(--space-8);
}

@media (max-width: 640px) {
  .page {
    padding: var(--space-6) 0;
  }

  .container {
    padding: 0 var(--space-4);
  }

  .title {
    font-size: var(--text-2xl);
  }
}
</style>
