<template>
  <div class="page">
    <!-- 顶部导航 -->
    <div class="chat-header">
      <NuxtLink to="/" class="back-link">
        <el-icon aria-hidden="true"><ArrowLeft /></el-icon>
        返回分析
      </NuxtLink>
      <div class="session-info">
        <span class="session-label">苏格拉底式对话</span>
      </div>
    </div>

    <!-- 聊天区域 -->
    <div class="chat-container">
      <div ref="messagesRef" class="messages" @scroll="onScroll">
        <!-- 空状态 -->
        <div v-if="messages.length === 0 && !loading" class="empty-state">
          <div class="empty-icon" aria-hidden="true">🧑‍🏫</div>
          <p class="empty-title">{{ sessionId ? 'AI 导师已准备就绪' : '请先上传视频开始分析' }}</p>
          <p class="empty-desc">
            {{ sessionId ? '视频分析已完成，请开始向 AI 导师提问，反思您的教学' : '前往首页上传微课视频，获取 AI 苏格拉底式点评后再来对话' }}
          </p>
          <!-- 快捷问题 -->
          <div v-if="sessionId" class="quick-questions">
            <p class="quick-label">试试这些问题：</p>
            <button
              v-for="q in quickQuestions"
              :key="q"
              class="quick-btn"
              :disabled="loading"
              @click="sendQuick(q)"
            >
              {{ q }}
            </button>
          </div>
        </div>

        <!-- 加载状态 -->
        <div v-if="loading && messages.length === 0" class="loading-state">
          <div class="loading-dots" aria-hidden="true">
            <span /><span /><span />
          </div>
          <p>AI 导师正在思考...</p>
        </div>

        <!-- 消息列表 -->
        <TransitionGroup name="msg">
          <div
            v-for="(msg, idx) in messages"
            :key="idx"
            :class="['message-row', msg.role]"
          >
            <div class="message-avatar" aria-hidden="true">
              {{ msg.role === 'user' ? '👤' : '🧑‍🏫' }}
            </div>
            <div class="message-bubble">
              <div class="message-content" v-html="renderMessage(msg.content)"></div>
              <!-- 复制按钮（仅 AI 消息） -->
              <button
                v-if="msg.role === 'assistant' && msg.content"
                class="copy-btn"
                title="复制消息"
                @click="copyMessage(msg.content)"
              >
                📋
              </button>
            </div>
          </div>
        </TransitionGroup>

        <!-- 打字光标 -->
        <div v-if="loading && messages.length > 0" class="typing-indicator">
          <span class="typing-cursor">|</span>
        </div>
      </div>

      <!-- 输入区域 -->
      <div class="input-section">
        <div class="input-wrapper">
          <el-input
            v-model="inputMessage"
            type="textarea"
            :rows="2"
            placeholder="输入您的问题或反思，AI 导师将引导您深入思考..."
            :disabled="loading"
            @keydown.enter.exact.prevent="sendMessage"
            @keydown.escape="blurInput"
          />
          <div class="input-actions">
            <span class="input-hint">Enter 发送 · Shift+Enter 换行</span>
            <div class="buttons">
              <el-button size="small" :disabled="loading" @click="clearChat">清除</el-button>
              <el-button
                type="primary"
                :loading="loading"
                :disabled="!inputMessage.trim()"
                @click="sendMessage"
              >
                发送
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ArrowLeft } from '@element-plus/icons-vue'
import type { ChatMessage } from '~/types'
import { DEMO_CHAT_INITIAL, getDemoChatReply } from '~/data/demoData'

const route = useRoute()
const sessionId = computed(() => (route.query.session as string) || '')

// 演示对话模式（体验版）：session 为 demo-session-001 时走本地回复
const isDemoSession = computed(() => sessionId.value === 'demo-session-001')

// 探测体验版轻量对话后端是否可用（返回 true 表示可用真实 DeepSeek）
const checkTrialBackend = async (): Promise<boolean> => {
  try {
    const res = await fetch('/api/v1/health')
    if (!res.ok) return false
    const data = await res.json()
    return data.status === 'ok' && data.api_key_configured === true
  } catch {
    return false
  }
}

const inputMessage = ref('')
const loading = ref(false)
const messages = ref<ChatMessage[]>([])
const messagesRef = ref<HTMLElement>()
const inputRef = ref<HTMLInputElement>()

// 快捷问题
const quickQuestions = [
  '帮我分析一下导入环节的设计',
  '我的教学内容深度够吗？',
  '这节课的互动设计如何改进？',
  '请指出我最需要改进的地方',
]

// --- 消息渲染（简单 Markdown） ---
const renderMessage = (text: string): string => {
  if (!text) return ''
  // 加粗
  let html = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  // 行内代码
  html = html.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>')
  // 换行
  html = html.replace(/\n/g, '<br>')
  return html
}

// --- 发送消息 ---
const sendMessage = async () => {
  const text = inputMessage.value.trim()
  if (!text || loading.value) return

  inputMessage.value = ''
  messages.value.push({ role: 'user', content: text })
  loading.value = true
  scrollToBottom()

  // 演示对话模式：优先真实 DeepSeek，失败回退本地模拟
  if (isDemoSession.value) {
    if (await checkTrialBackend()) {
      try {
        const response = await fetch('/api/v1/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: sessionId.value, message: text }),
        })
        if (response.ok) {
          await streamResponse(response)
          loading.value = false
          scrollToBottom()
          return
        }
      } catch (e) {
        console.error('Trial backend unavailable, fallback to local:', e)
      }
    }
    // 回退本地模拟
    await new Promise((resolve) => setTimeout(resolve, 500))
    const reply = getDemoChatReply(text)
    messages.value.push({ role: 'assistant', content: reply })
    loading.value = false
    scrollToBottom()
    return
  }

  try {
    const response = await fetch('/api/v1/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId.value, message: text }),
    })

    if (!response.ok) {
      throw new Error(`服务器响应异常 (${response.status})`)
    }

    await streamResponse(response)
  } catch (error) {
    const msg = error instanceof Error ? error.message : '发送失败，请重试'
    ElMessage.error(msg)
    console.error('Chat error:', error)
  } finally {
    loading.value = false
  }
}

const sendQuick = (question: string) => {
  inputMessage.value = question
  sendMessage()
}

// --- SSE 流式接收 ---
const streamResponse = async (response: Response) => {
  const reader = response.body?.getReader()
  if (!reader) throw new Error('无法读取响应流')

  const decoder = new TextDecoder()
  let fullContent = ''
  let buffer = ''

  messages.value.push({ role: 'assistant', content: '' })
  const msgIndex = messages.value.length - 1

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() || ''

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const data = JSON.parse(line.slice(6))

          if (data.error) {
            ElMessage.error(data.error)
            return
          }

          if (data.text) {
            fullContent += data.text
            if (messages.value[msgIndex]) {
              messages.value[msgIndex].content = fullContent
            }
            scrollToBottom()
          }
        } catch {
          // 忽略解析碎片
        }
      }
    }
  }
}

// --- 滚动 ---
const isNearBottom = ref(true)

const onScroll = () => {
  if (!messagesRef.value) return
  const { scrollTop, scrollHeight, clientHeight } = messagesRef.value
  isNearBottom.value = scrollHeight - scrollTop - clientHeight < 120
}

const scrollToBottom = () => {
  nextTick(() => {
    if (messagesRef.value && isNearBottom.value) {
      messagesRef.value.scrollTo({
        top: messagesRef.value.scrollHeight,
        behavior: 'smooth',
      })
    }
  })
}

// --- 复制 ---
const copyMessage = async (text: string) => {
  try {
    await navigator.clipboard.writeText(text)
    ElMessage.success('已复制')
  } catch {
    ElMessage.error('复制失败')
  }
}

// --- 清除对话 ---
const clearChat = async () => {
  try {
    // 演示对话模式：仅清空本地消息，不调用后端
    if (sessionId.value && !isDemoSession.value) {
      await fetch('/api/v1/chat/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionId.value }),
      })
    }
    messages.value = []
    ElMessage.success('对话已清除')
  } catch (error) {
    ElMessage.error('清除失败')
    console.error('Clear error:', error)
  }
}

const blurInput = () => {
  ;(document.activeElement as HTMLElement)?.blur()
}

// --- AI 初始点评 ---
const fetchAIInitial = async () => {
  if (!sessionId.value) return

  // 演示对话模式：优先真实 DeepSeek 初始点评，失败回退本地
  if (isDemoSession.value) {
    if (await checkTrialBackend()) {
      loading.value = true
      try {
        const response = await fetch('/api/v1/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: sessionId.value, message: '' }),
        })
        if (response.ok) {
          await streamResponse(response)
          loading.value = false
          return
        }
      } catch (e) {
        console.error('Trial backend unavailable for initial:', e)
      }
      loading.value = false
    }
    messages.value.push({ role: 'assistant', content: DEMO_CHAT_INITIAL })
    return
  }

  loading.value = true

  try {
    const response = await fetch('/api/v1/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId.value, message: '' }),
    })

    if (!response.ok) {
      throw new Error(`服务器响应异常 (${response.status})`)
    }

    await streamResponse(response)
  } catch (error) {
    const msg = error instanceof Error ? error.message : '获取 AI 点评失败'
    ElMessage.error(msg)
    console.error('Initial fetch error:', error)
  } finally {
    loading.value = false
  }
}

// --- 路由监听 ---
watch(
  () => route.query.session,
  (newId) => {
    if (newId && messages.value.length === 0) {
      fetchAIInitial()
    }
  }
)

onMounted(() => {
  if (sessionId.value) {
    fetchAIInitial()
  }
})
</script>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 64px);
  padding: 0;
}

/* --- Header --- */
.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-4) var(--space-6);
  background: var(--bg-card);
  border-bottom: 1px solid var(--border-subtle);
  flex-shrink: 0;
}

.back-link {
  display: flex;
  align-items: center;
  gap: 6px;
  color: var(--text-secondary);
  font-size: var(--text-sm);
  text-decoration: none;
  transition: color var(--transition-fast) var(--ease-out);
}

.back-link:hover {
  color: var(--accent-blue);
}

.session-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  font-weight: var(--font-medium);
}

/* --- Chat container --- */
.chat-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  max-width: 900px;
  width: 100%;
  margin: 0 auto;
  overflow: hidden;
}

/* --- Messages --- */
.messages {
  flex: 1;
  overflow-y: auto;
  padding: var(--space-6);
  display: flex;
  flex-direction: column;
  gap: var(--space-6);
  scroll-behavior: smooth;
}

/* --- Empty state --- */
.empty-state {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: var(--space-10);
}

.empty-icon {
  font-size: 64px;
  margin-bottom: var(--space-5);
  opacity: 0.8;
}

.empty-title {
  font-size: var(--text-xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.empty-desc {
  font-size: var(--text-sm);
  color: var(--text-muted);
  max-width: 360px;
  line-height: var(--leading-relaxed);
}

/* --- Quick questions --- */
.quick-questions {
  margin-top: var(--space-8);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-2);
}

.quick-label {
  font-size: var(--text-xs);
  color: var(--text-muted);
  margin-bottom: var(--space-2);
}

.quick-btn {
  padding: var(--space-2) var(--space-4);
  background: var(--bg-input);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-full);
  color: var(--text-secondary);
  font-size: var(--text-sm);
  cursor: pointer;
  transition: all var(--transition-fast) var(--ease-out);
}

.quick-btn:hover {
  border-color: var(--accent-blue);
  color: var(--accent-blue);
  background: var(--accent-blue-subtle);
}

/* --- Loading --- */
.loading-state {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-4);
}

.loading-dots {
  display: flex;
  gap: 6px;
}

.loading-dots span {
  width: 8px;
  height: 8px;
  background: var(--accent-blue);
  border-radius: 50%;
  animation: pulse-dot 1.4s infinite ease-in-out both;
}

.loading-dots span:nth-child(1) { animation-delay: -0.32s; }
.loading-dots span:nth-child(2) { animation-delay: -0.16s; }

.loading-state p {
  color: var(--text-secondary);
  font-size: var(--text-sm);
}

/* --- Typing cursor --- */
.typing-indicator {
  padding-left: 52px;
  font-size: var(--text-base);
  color: var(--accent-blue);
  animation: fade-in 300ms var(--ease-out);
}

.typing-cursor {
  animation: fade-in 0.6s var(--ease-out) infinite alternate;
}

/* --- Message row --- */
.message-row {
  display: flex;
  gap: var(--space-3);
  max-width: 85%;
}

.message-row.user {
  align-self: flex-end;
  flex-direction: row-reverse;
}

.message-row.assistant {
  align-self: flex-start;
}

/* --- Message avatar --- */
.message-avatar {
  font-size: 28px;
  flex-shrink: 0;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-input);
  border-radius: 50%;
}

.message-row.user .message-avatar {
  background: var(--accent-blue);
}

/* --- Message bubble --- */
.message-bubble {
  flex: 1;
  min-width: 0;
  position: relative;
}

.message-bubble:hover .copy-btn {
  opacity: 1;
}

.message-content {
  padding: var(--space-4) var(--space-5);
  border-radius: var(--radius-xl);
  font-size: var(--text-base);
  line-height: var(--leading-relaxed);
  white-space: pre-wrap;
  word-break: break-word;
}

.message-content :deep(.inline-code) {
  background: rgba(255, 255, 255, 0.1);
  padding: 1px 5px;
  border-radius: var(--radius-sm);
  font-family: var(--font-mono);
  font-size: 0.9em;
}

.message-content :deep(strong) {
  font-weight: var(--font-semibold);
}

.message-row.user .message-content {
  background: var(--accent-blue);
  color: white;
  border-bottom-right-radius: var(--radius-sm);
}

.message-row.assistant .message-content {
  background: var(--bg-input);
  color: var(--text-primary);
  border-bottom-left-radius: var(--radius-sm);
}

/* --- Copy button --- */
.copy-btn {
  position: absolute;
  top: -8px;
  right: -8px;
  width: 28px;
  height: 28px;
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-sm);
  background: var(--bg-elevated);
  font-size: 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity var(--transition-fast) var(--ease-out);
}

.copy-btn:hover {
  border-color: var(--accent-blue);
}

/* --- Transition --- */
.msg-enter-active {
  animation: fade-in-up 300ms var(--ease-out) both;
}

/* --- Input --- */
.input-section {
  padding: var(--space-5) var(--space-6);
  background: var(--bg-card);
  border-top: 1px solid var(--border-subtle);
  flex-shrink: 0;
}

.input-wrapper {
  max-width: 900px;
  margin: 0 auto;
}

.input-wrapper :deep(.el-textarea__inner) {
  background: var(--bg-input) !important;
  border: 1px solid var(--border-subtle) !important;
  color: var(--text-primary) !important;
  border-radius: var(--radius-lg);
  padding: var(--space-3) var(--space-4);
  font-size: var(--text-base);
  line-height: var(--leading-relaxed);
  resize: none;
}

.input-wrapper :deep(.el-textarea__inner:focus) {
  border-color: var(--accent-blue) !important;
}

.input-wrapper :deep(.el-textarea__inner::placeholder) {
  color: var(--text-muted) !important;
}

.input-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: var(--space-3);
}

.input-hint {
  font-size: var(--text-xs);
  color: var(--text-muted);
}

.buttons {
  display: flex;
  gap: var(--space-2);
}

/* --- Responsive --- */
@media (max-width: 640px) {
  .chat-header {
    padding: var(--space-3) var(--space-4);
  }

  .messages {
    padding: var(--space-4);
    gap: var(--space-4);
  }

  .message-row {
    max-width: 92%;
  }

  .input-section {
    padding: var(--space-4);
  }

  .input-hint {
    display: none;
  }
}
</style>
