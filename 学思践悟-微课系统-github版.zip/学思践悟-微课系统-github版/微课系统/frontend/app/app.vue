<template>
  <div class="app-container">
    <NuxtRouteAnnouncer />
    <NuxtLoadingIndicator color="var(--accent-blue)" :height="3" />
    <NuxtErrorBoundary>
      <NuxtLayout>
        <NuxtPage />
      </NuxtLayout>
      <template #error="{ error }">
        <div class="error-boundary">
          <div class="error-content">
            <span class="error-icon" aria-hidden="true">⚠️</span>
            <h2 class="error-title">页面加载出错</h2>
            <p class="error-desc">请刷新页面重试，如果问题持续存在请联系管理员</p>
            <el-button type="primary" @click="error?.clear">重试</el-button>
          </div>
        </div>
      </template>
    </NuxtErrorBoundary>
  </div>
</template>

<script setup lang="ts">
// App root — NuxtLayout + NuxtPage 已在 template 中使用
</script>

<style>
.app-container {
  min-height: 100vh;
  background-color: var(--bg-dark);
  color: var(--text-primary);
}

/* --- Error boundary fallback --- */
.error-boundary {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: var(--space-10);
}

.error-content {
  text-align: center;
  max-width: 400px;
}

.error-icon {
  font-size: 48px;
  display: block;
  margin-bottom: var(--space-4);
}

.error-title {
  font-size: var(--text-xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.error-desc {
  font-size: var(--text-sm);
  color: var(--text-muted);
  margin-bottom: var(--space-6);
  line-height: var(--leading-relaxed);
}
</style>
