<template>
  <el-card v-if="visionData" class="vision-card">
    <template #header>
      <div class="card-header">
        <span class="card-title" id="vision-heading">🎭 教态数据</span>
        <span class="hint-text">（仅后台参考，对话中不会主动提及）</span>
      </div>
    </template>
    <div class="vision-grid" role="region" aria-labelledby="vision-heading">
      <div class="vision-item">
        <span class="vision-label">背对学生时间</span>
        <span class="vision-value">{{ (visionData.back_ratio * 100).toFixed(1) }}%</span>
      </div>
      <div class="vision-item">
        <span class="vision-label">手势频次</span>
        <span class="vision-value">{{ visionData.gesture_intensity }} 次</span>
      </div>
      <div class="vision-item">
        <span class="vision-label">手势幅度</span>
        <span class="vision-value">{{ visionData.gesture_level }}</span>
      </div>
      <div class="vision-item">
        <span class="vision-label">左右均衡度</span>
        <span class="vision-value">{{ visionData.hand_balance }}%</span>
      </div>
      <div class="vision-item">
        <span class="vision-label">位移幅度</span>
        <span class="vision-value">{{ visionData.movement_range }}</span>
      </div>
      <div class="vision-item">
        <span class="vision-label">站位状态</span>
        <span class="vision-value">{{ visionData.is_stiff ? '较为固定' : '灵活' }}</span>
      </div>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import type { VisionAnalysis } from '~/types'

defineProps<{
  visionData: VisionAnalysis
}>()
</script>

<style scoped>
.vision-card {
  animation: fade-in-up 400ms var(--ease-out) both;
  animation-delay: 300ms;
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.card-title {
  font-size: var(--text-md);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.hint-text {
  font-size: var(--text-xs);
  color: var(--text-muted);
}

.vision-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--space-4);
}

.vision-item {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  padding: var(--space-3) var(--space-4);
  background: var(--bg-input);
  border-radius: var(--radius-md);
}

.vision-label {
  font-size: var(--text-xs);
  color: var(--text-muted);
}

.vision-value {
  font-size: var(--text-md);
  font-weight: var(--font-semibold);
  color: var(--accent-blue);
}

@media (max-width: 768px) {
  .vision-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 640px) {
  .vision-grid {
    grid-template-columns: 1fr;
  }
}
</style>
