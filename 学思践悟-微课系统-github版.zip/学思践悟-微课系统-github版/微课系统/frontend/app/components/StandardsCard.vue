<template>
  <el-card v-if="standards?.length" class="standards-card">
    <template #header>
      <div class="card-header">
        <span class="card-title" id="standards-heading">📚 引用课标</span>
      </div>
    </template>
    <ul class="standards-list" role="list" aria-labelledby="standards-heading">
      <li v-for="(standard, idx) in standards" :key="idx" role="listitem">
        {{ standard }}
      </li>
    </ul>
  </el-card>
</template>

<script setup lang="ts">
defineProps<{
  standards: string[]
}>()
</script>

<style scoped>
.standards-card {
  animation: fade-in-up 400ms var(--ease-out) both;
  animation-delay: 150ms;
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.card-title {
  font-size: var(--text-md);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.standards-list {
  list-style: none;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}

.standards-list li {
  padding: var(--space-3) var(--space-4);
  background: var(--bg-input);
  border-radius: var(--radius-md);
  font-size: var(--text-sm);
  color: var(--text-secondary);
  border-left: 3px solid var(--accent-blue);
  line-height: var(--leading-relaxed);
}
</style>
