<template>
  <el-card v-if="alerts?.length" class="alerts-card">
    <template #header>
      <div class="card-header">
        <span class="card-title" id="alerts-heading">⚡ 教态智能预警</span>
        <span class="hint-text">（基于阈值自动分析）</span>
      </div>
    </template>
    <div class="alerts-list" role="status" aria-labelledby="alerts-heading">
      <div
        v-for="(alert, idx) in alerts"
        :key="idx"
        :class="['alert-item', `alert-${alert.level}`]"
        :role="alert.level === 'error' ? 'alert' : 'status'"
      >
        <span class="alert-icon" aria-hidden="true">{{ alertIcon(alert.level) }}</span>
        <span class="alert-msg">{{ alert.msg }}</span>
      </div>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import type { VisionAlert } from '~/types'

defineProps<{
  alerts: VisionAlert[]
}>()

const alertIcon = (level: string): string => {
  const icons: Record<string, string> = { error: '🔴', warning: '🟡', info: '🔵', success: '✅' }
  return icons[level] || 'ℹ️'
}
</script>

<style scoped>
.alerts-card {
  animation: fade-in-up 400ms var(--ease-out) both;
  animation-delay: 250ms;
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.card-title {
  font-size: var(--text-md);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.hint-text {
  font-size: var(--text-xs);
  color: var(--text-muted);
}

.alerts-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}

.alert-item {
  display: flex;
  align-items: flex-start;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  border-radius: var(--radius-md);
  font-size: var(--text-sm);
  line-height: var(--leading-relaxed);
}

.alert-error {
  background: var(--color-error-bg);
  border: 1px solid rgba(239, 68, 68, 0.3);
  color: var(--color-error-text);
}

.alert-warning {
  background: var(--color-warning-bg);
  border: 1px solid rgba(245, 158, 11, 0.3);
  color: var(--color-warning-text);
}

.alert-info {
  background: var(--color-info-bg);
  border: 1px solid rgba(59, 130, 246, 0.3);
  color: var(--color-info-text);
}

.alert-success {
  background: var(--color-success-bg);
  border: 1px solid rgba(34, 197, 94, 0.3);
  color: var(--color-success-text);
}

.alert-icon {
  flex-shrink: 0;
  font-size: var(--text-md);
}

.alert-msg {
  flex: 1;
}
</style>
