<template>
  <el-card v-if="scores?.length" class="scoring-card">
    <template #header>
      <div class="card-header">
        <span class="card-title" id="scoring-heading">📊 多维评分卡</span>
        <el-button
          size="small"
          text
          :aria-expanded="showScoring"
          aria-controls="scoring-content"
          @click="showScoring = !showScoring"
        >
          {{ showScoring ? '收起' : '点击查看评分卡' }}
          <el-icon class="el-icon--right">
            <ArrowDown v-if="!showScoring" />
            <ArrowUp v-else />
          </el-icon>
        </el-button>
      </div>
    </template>
    <div v-if="showScoring" id="scoring-content" class="scoring-grid" role="region" aria-labelledby="scoring-heading">
      <div v-for="item in scores" :key="item.name" class="score-row">
        <div class="score-info">
          <span class="score-name">{{ item.name }}</span>
          <span class="score-comment">{{ item.comment }}</span>
        </div>
        <div class="score-bar-wrap">
          <div
            class="score-bar"
            :class="scoreColorClass(item.score)"
            :style="{ width: item.score + '%' }"
            role="progressbar"
            :aria-valuenow="item.score"
            aria-valuemin="0"
            aria-valuemax="100"
            :aria-label="`${item.name} ${item.score}分`"
          />
        </div>
        <span class="score-num" :class="scoreColorClass(item.score)">{{ item.score }}</span>
      </div>
      <div class="score-row score-total">
        <span class="score-name">综合平均</span>
        <span class="score-num total-score">{{ avgScore }}</span>
      </div>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import { ArrowDown, ArrowUp } from '@element-plus/icons-vue'
import type { ScoreItem } from '~/types'

const props = defineProps<{
  scores: ScoreItem[]
}>()

const showScoring = ref(false)

const scoreColorClass = (score: number): string => {
  if (score >= 85) return 'score-high'
  if (score >= 70) return 'score-mid'
  return 'score-low'
}

const avgScore = computed(() => {
  if (!props.scores?.length) return '—'
  return Math.round(props.scores.reduce((sum, s) => sum + s.score, 0) / props.scores.length)
})
</script>

<style scoped>
.scoring-card {
  animation: fade-in-up 400ms var(--ease-out) both;
  animation-delay: 200ms;
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.card-title {
  font-size: var(--text-md);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.scoring-grid {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}

.score-row {
  display: flex;
  align-items: center;
  gap: var(--space-4);
}

.score-info {
  flex: 1;
  min-width: 0;
  display: flex;
  align-items: baseline;
  gap: var(--space-3);
}

.score-name {
  font-size: var(--text-sm);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  white-space: nowrap;
  width: 80px;
}

.score-comment {
  font-size: var(--text-xs);
  color: var(--text-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.score-bar-wrap {
  width: 140px;
  height: 8px;
  background: var(--bg-input);
  border-radius: var(--radius-full);
  overflow: hidden;
  flex-shrink: 0;
}

.score-bar {
  height: 100%;
  border-radius: var(--radius-full);
  transition: width 0.4s var(--ease-out);
}

.score-bar.score-high { background: var(--color-success); }
.score-bar.score-mid  { background: var(--color-warning); }
.score-bar.score-low  { background: var(--color-error); }

.score-num {
  font-size: var(--text-lg);
  font-weight: var(--font-bold);
  width: 36px;
  text-align: right;
}

.score-num.score-high { color: var(--color-success); }
.score-num.score-mid  { color: var(--color-warning); }
.score-num.score-low  { color: var(--color-error); }

.score-total {
  margin-top: var(--space-2);
  padding-top: var(--space-3);
  border-top: 1px solid var(--border-subtle);
}

.total-score {
  font-size: var(--text-2xl);
  color: var(--accent-blue);
}

@media (max-width: 640px) {
  .score-bar-wrap {
    width: 80px;
  }

  .score-comment {
    display: none;
  }
}
</style>
