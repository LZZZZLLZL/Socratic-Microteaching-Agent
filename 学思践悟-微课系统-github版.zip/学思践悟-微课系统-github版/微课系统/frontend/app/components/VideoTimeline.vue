<template>
  <el-card v-if="videoUrl && timeline?.length" class="player-card">
    <template #header>
      <div class="card-header">
        <span class="card-title">🎬 视频回放与分析时间轴</span>
      </div>
    </template>

    <div class="player-body">
      <!-- 视频播放器 -->
      <video
        ref="videoPlayer"
        :src="videoUrl"
        class="video-player"
        controls
        aria-label="教学视频回放"
        @timeupdate="onTimeUpdate"
        @loadedmetadata="onVideoLoaded"
      />

      <!-- 时间轴容器 -->
      <div class="timeline-container">
        <!-- 手势标记行 -->
        <div class="timeline-gestures" ref="gestureTrack">
          <div
            v-for="(seg, idx) in timeline"
            :key="'g-' + idx"
            class="gesture-dot"
            :class="{ active: seg.gesture > 0 }"
            :style="segmentStyle(seg)"
            :title="gestureTitle(seg)"
          />
        </div>

        <!-- 时间轴主轨道 -->
        <div
          class="timeline-track"
          ref="timelineTrack"
          role="slider"
          :aria-label="`播放进度 ${formatTime(currentTime)} / ${formatTime(videoDuration)}`"
          :aria-valuenow="Math.round(currentTime)"
          :aria-valuemin="0"
          :aria-valuemax="Math.round(videoDuration)"
          tabindex="0"
          @click="seekTo"
          @keydown.left.prevent="seekRelative(-5)"
          @keydown.right.prevent="seekRelative(5)"
        >
          <div
            v-for="(seg, idx) in timeline"
            :key="idx"
            class="timeline-segment"
            :class="{ 'is-back': seg.back, 'is-current': currentSegIdx === idx }"
            :style="segmentStyle(seg)"
            :title="(seg.back ? '⚠ 背对学生 · ' : '') + seg.text"
            @mouseenter="hoveredSeg = seg"
            @mouseleave="hoveredSeg = null"
          />
          <div class="timeline-cursor" :style="{ left: cursorLeft + '%' }" />
        </div>

        <!-- 时间刻度 -->
        <div class="timeline-ticks">
          <span
            v-for="tick in timeTicks"
            :key="tick.t"
            class="tick"
            :style="{ left: tick.pct + '%' }"
          >{{ tick.label }}</span>
        </div>

        <!-- 悬浮文字预览 -->
        <div v-if="hoveredSeg" class="timeline-tooltip" aria-live="polite">
          <span v-if="hoveredSeg.back" class="tooltip-tag tooltip-back">⚠ 背对</span>
          <span v-if="hoveredSeg.gesture > 0" class="tooltip-tag tooltip-gesture">👋 ×{{ hoveredSeg.gesture }}</span>
          <span class="tooltip-text">{{ hoveredSeg.text }}</span>
          <span class="tooltip-time">{{ formatTime(hoveredSeg.start) }} – {{ formatTime(hoveredSeg.end) }}</span>
        </div>
      </div>

      <!-- 图例 -->
      <div class="timeline-legend">
        <span class="legend-item">
          <span class="legend-swatch normal" aria-hidden="true" /> 正常
        </span>
        <span class="legend-item">
          <span class="legend-swatch back" aria-hidden="true" /> 背对学生
        </span>
        <span class="legend-item">
          <span class="legend-swatch gesture" aria-hidden="true" /> 👋 手势
        </span>
      </div>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import type { TimelineSegment } from '~/types'

const props = defineProps<{
  videoUrl: string
  timeline: TimelineSegment[]
  duration: number
}>()

// --- Refs ---
const videoPlayer = ref<HTMLVideoElement>()
const timelineTrack = ref<HTMLElement>()
const currentTime = ref(0)
const videoDuration = ref(0)
const hoveredSeg = ref<TimelineSegment | null>(null)
const currentSegIdx = ref(-1)

// --- Video events ---
const onVideoLoaded = () => {
  if (videoPlayer.value) {
    videoDuration.value = videoPlayer.value.duration
  }
}

const onTimeUpdate = () => {
  if (videoPlayer.value) {
    currentTime.value = videoPlayer.value.currentTime
    currentSegIdx.value = props.timeline.findIndex(
      (seg) => currentTime.value >= seg.start && currentTime.value < seg.end
    )
  }
}

// --- Timeline positioning ---
const segmentStyle = (seg: TimelineSegment) => {
  const duration = videoDuration.value || props.duration || 1
  const left = (seg.start / duration) * 100
  const width = Math.max(((seg.end - seg.start) / duration) * 100, 0.5)
  return { left: left + '%', width: width + '%' }
}

const cursorLeft = computed(() => {
  const duration = videoDuration.value || 1
  return (currentTime.value / duration) * 100
})

// --- Time ticks ---
const timeTicks = computed(() => {
  const duration = videoDuration.value || props.duration || 60
  const ticks = []
  const interval = duration <= 60 ? 10 : duration <= 180 ? 30 : 60
  for (let t = 0; t <= duration; t += interval) {
    ticks.push({ t, pct: (t / duration) * 100, label: formatTime(t) })
  }
  return ticks
})

// --- Helpers ---
const formatTime = (seconds: number): string => {
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}

const gestureTitle = (seg: TimelineSegment): string => {
  if (seg.gesture > 0) return seg.gesture + ' 次手势 · ' + seg.text
  return seg.text
}

// --- Seek ---
const seekTo = (e: MouseEvent) => {
  if (!timelineTrack.value || !videoPlayer.value) return
  const rect = timelineTrack.value.getBoundingClientRect()
  const pct = (e.clientX - rect.left) / rect.width
  videoPlayer.value.currentTime = pct * videoDuration.value
}

const seekRelative = (deltaSec: number) => {
  if (!videoPlayer.value) return
  videoPlayer.value.currentTime = Math.max(0, Math.min(videoDuration.value, videoPlayer.value.currentTime + deltaSec))
}
</script>

<style scoped>
.player-card {
  animation: fade-in-up 400ms var(--ease-out) both;
  animation-delay: 50ms;
}

.player-card :deep(.el-card__body) {
  padding: 0;
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.card-title {
  font-size: var(--text-md);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.player-body {
  display: flex;
  flex-direction: column;
}

/* --- Video player --- */
.video-player {
  width: 100%;
  max-height: 480px;
  background: #000;
  display: block;
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
}

/* --- Timeline container --- */
.timeline-container {
  padding: var(--space-4) var(--space-5) var(--space-3);
  position: relative;
  background: var(--bg-input);
}

/* --- Gesture dots --- */
.timeline-gestures {
  height: 18px;
  position: relative;
  margin-bottom: 4px;
}

.gesture-dot {
  position: absolute;
  top: 2px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: transparent;
  transform: translateX(-50%);
  transition: background var(--transition-fast) var(--ease-out);
}

.gesture-dot.active {
  background: var(--color-warning);
  box-shadow: 0 0 4px rgba(245, 158, 11, 0.6);
}

/* --- Timeline track --- */
.timeline-track {
  height: 32px;
  background: var(--bg-dark);
  border-radius: var(--radius-sm);
  position: relative;
  cursor: pointer;
  overflow: hidden;
}

.timeline-track:hover {
  outline: 1px solid var(--accent-blue);
}

.timeline-track:focus-visible {
  outline: 2px solid var(--accent-blue);
  outline-offset: 2px;
}

.timeline-segment {
  position: absolute;
  top: 0;
  height: 100%;
  background: rgba(59, 130, 246, 0.5);
  border-right: 1px solid rgba(255, 255, 255, 0.1);
  transition: background var(--transition-fast) var(--ease-out);
}

.timeline-segment.is-back {
  background: rgba(239, 68, 68, 0.7);
}

.timeline-segment.is-current {
  background: rgba(255, 255, 255, 0.7) !important;
  z-index: 2;
}

.timeline-segment:hover {
  filter: brightness(1.4);
}

/* --- Cursor --- */
.timeline-cursor {
  position: absolute;
  top: -4px;
  bottom: -4px;
  width: 2px;
  background: #fff;
  z-index: 3;
  pointer-events: none;
  transition: left 0.1s linear;
}

/* --- Ticks --- */
.timeline-ticks {
  height: 20px;
  position: relative;
  margin-top: 4px;
}

.tick {
  position: absolute;
  transform: translateX(-50%);
  font-size: 11px;
  color: var(--text-muted);
  font-family: var(--font-mono);
}

/* --- Tooltip --- */
.timeline-tooltip {
  margin-top: var(--space-2);
  padding: var(--space-2) var(--space-3);
  background: var(--bg-elevated);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-md);
  font-size: var(--text-xs);
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
  min-height: 36px;
}

.tooltip-tag {
  padding: 1px 6px;
  border-radius: var(--radius-sm);
  font-size: 11px;
  font-weight: var(--font-medium);
}

.tooltip-back {
  background: var(--color-error-bg);
  color: var(--color-error);
}

.tooltip-gesture {
  background: var(--color-warning-bg);
  color: var(--color-warning);
}

.tooltip-text {
  color: var(--text-primary);
  flex: 1;
  min-width: 150px;
}

.tooltip-time {
  color: var(--text-muted);
  font-family: var(--font-mono);
}

/* --- Legend --- */
.timeline-legend {
  display: flex;
  gap: var(--space-5);
  padding: var(--space-2) var(--space-5) var(--space-3);
  font-size: var(--text-xs);
  color: var(--text-secondary);
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

.legend-swatch {
  width: 12px;
  height: 12px;
  border-radius: var(--radius-sm);
}

.legend-swatch.normal {
  background: rgba(59, 130, 246, 0.5);
}

.legend-swatch.back {
  background: rgba(239, 68, 68, 0.7);
}

.legend-swatch.gesture {
  background: var(--color-warning);
  border-radius: 50%;
  box-shadow: 0 0 4px rgba(245, 158, 11, 0.6);
}

@media (max-width: 640px) {
  .video-player {
    max-height: 280px;
  }

  .timeline-tooltip {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-1);
  }

  .tooltip-text {
    min-width: unset;
  }
}
</style>
