<template>
  <div v-if="!analyzing && !hasResult" class="upload-section">
    <el-upload
      ref="uploadRef"
      class="upload"
      drag
      :auto-upload="false"
      :limit="1"
      accept="video/*"
      :on-change="handleChange"
      :file-list="fileList"
    >
      <div class="upload-content">
        <el-icon class="upload-icon" aria-hidden="true"><UploadFilled /></el-icon>
        <div class="upload-text">
          <span class="upload-title">拖拽视频文件到此处</span>
          <span class="upload-hint">或点击选择文件，支持 MP4、MOV 等格式</span>
        </div>
      </div>
    </el-upload>

    <el-button
      v-if="selectedFile"
      type="primary"
      size="large"
      class="analyze-btn"
      :loading="analyzing"
      @click="$emit('start-analysis')"
    >
      开始分析
    </el-button>

    <el-button
      size="large"
      class="demo-btn"
      @click="$emit('start-demo')"
    >
      演示模式（不上传视频）
    </el-button>
  </div>
</template>

<script setup lang="ts">
import { UploadFilled } from '@element-plus/icons-vue'

const props = defineProps<{
  analyzing: boolean
  hasResult: boolean
}>()

const emit = defineEmits<{
  'file-change': [file: File]
  'start-analysis': []
  'start-demo': []
}>()

const uploadRef = ref()
const selectedFile = ref<File | null>(null)
const fileList = ref<any[]>([])

const handleChange = (file: any) => {
  selectedFile.value = file.raw
  fileList.value = [file]
  emit('file-change', file.raw)
}

defineExpose({ selectedFile })
</script>

<style scoped>
.upload-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-6);
  animation: fade-in-up 400ms var(--ease-out) both;
}

.upload {
  width: 100%;
}

.upload-content {
  padding: var(--space-10) 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-4);
}

.upload-icon {
  font-size: 48px;
  color: var(--accent-blue);
}

.upload-text {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-2);
}

.upload-title {
  font-size: var(--text-md);
  font-weight: var(--font-medium);
  color: var(--text-primary);
}

.upload-hint {
  font-size: var(--text-sm);
  color: var(--text-muted);
}

.analyze-btn {
  width: 200px;
}

.demo-btn {
  background: var(--bg-input);
  border-color: var(--border-subtle);
  color: var(--text-secondary);
}

.demo-btn:hover {
  background: var(--bg-elevated);
  border-color: var(--accent-blue);
  color: var(--accent-blue);
}
</style>
