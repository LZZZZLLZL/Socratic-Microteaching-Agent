<template>
  <el-card class="transcription-card">
    <template #header>
      <div class="card-header">
        <span class="card-title" id="transcription-heading">📝 教学内容（语音转写）</span>
      </div>
    </template>
    <div class="transcription" role="region" aria-labelledby="transcription-heading">
      {{ text || '（未检测到语音内容）' }}
    </div>
  </el-card>
</template>

<script setup lang="ts">
defineProps<{
  text: string
}>()
</script>

<style scoped>
.transcription-card {
  animation: fade-in-up 400ms var(--ease-out) both;
  animation-delay: 100ms;
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.card-title {
  font-size: var(--text-md);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.transcription {
  font-size: var(--text-base);
  line-height: var(--leading-relaxed);
  color: var(--text-secondary);
  white-space: pre-wrap;
}
</style>
