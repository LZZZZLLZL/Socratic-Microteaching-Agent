<template>
  <el-card class="feedback-card">
    <template #header>
      <div class="card-header">
        <span class="card-title">🤖 AI 点评</span>
        <span class="ai-badge">苏格拉底式引导</span>
      </div>
    </template>
    <div class="feedback-content" v-html="formattedFeedback"></div>
    <div class="action-buttons">
      <el-button type="primary" @click="$emit('go-chat')">
        开始对话
        <el-icon class="el-icon--right"><ArrowRight /></el-icon>
      </el-button>
      <el-button @click="$emit('export-report')">
        📄 导出报告
      </el-button>
      <el-button @click="$emit('reset')">分析新视频</el-button>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import { ArrowRight } from '@element-plus/icons-vue'

const props = defineProps<{
  feedback: string
  sessionId: string
}>()

const emit = defineEmits<{
  'go-chat': []
  'export-report': []
  'reset': []
}>()

const formattedFeedback = computed(() => {
  if (!props.feedback) return ''
  return props.feedback.replace(/\n/g, '<br>')
})
</script>

<style scoped>
.feedback-card {
  animation: fade-in-up 400ms var(--ease-out) both;
  animation-delay: 150ms;
}

.card-header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.card-title {
  font-size: var(--text-md);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.ai-badge {
  font-size: var(--text-xs);
  padding: 2px var(--space-2);
  background: var(--accent-blue-subtle);
  color: var(--accent-blue);
  border-radius: var(--radius-sm);
  font-weight: var(--font-medium);
}

.feedback-content {
  font-size: var(--text-base);
  line-height: var(--leading-relaxed);
  color: var(--text-primary);
  white-space: pre-wrap;
  margin-bottom: var(--space-6);
}

.action-buttons {
  display: flex;
  gap: var(--space-3);
  flex-wrap: wrap;
}
</style>
