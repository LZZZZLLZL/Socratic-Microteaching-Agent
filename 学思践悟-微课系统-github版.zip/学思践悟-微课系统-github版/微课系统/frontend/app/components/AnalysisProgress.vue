<template>
  <div v-if="analyzing" class="progress-section" role="status" aria-live="polite">
    <el-progress
      :percentage="progress"
      :stroke-width="12"
      :format="() => `${progress}%`"
    />
    <p class="progress-status">{{ statusText }}</p>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  progress: number
  statusText: string
  analyzing: boolean
}>()
</script>

<style scoped>
.progress-section {
  max-width: 600px;
  margin: var(--space-16) auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-4);
}

.progress-status {
  color: var(--text-secondary);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  animation: fade-in 300ms var(--ease-out);
}
</style>
