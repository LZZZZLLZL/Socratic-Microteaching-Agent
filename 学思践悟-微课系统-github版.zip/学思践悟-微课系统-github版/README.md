# 🍎 Socratic-Microteaching-Agent (学思践悟)

> **基于多智能体（Multi-Agent）与 RAG 技术的智慧教育实训复盘系统**

---

## ✨ 功能亮点

- 🧠 **苏格拉底式启发反馈**：Multi-Agent 协同，由 AI 导师提问引导师范生自主发现教学盲点
- 🎙️ **语音转写**：Whisper 模型识别教学语言（GPU/CPU 自动切换）
- 🖐️ **姿态分析**：YOLOv8 分析手势频次、左右手均衡度、背对率、位移幅度
- 📚 **本地 RAG**：FAISS 向量检索《信息科技课程标准》等规范，反馈有据可依
- ⚡ **SSE 流式输出**：AI 点评逐字实时显示
- 💬 **多轮对话**：与 AI 导师持续对话，深入复盘教学细节
- 🎮 **双模式启动**：体验版（快速演示 + 真实 AI 对话）与完整版（真实视频分析）

## 🧠 技术架构 (Technical Stack)

| 维度 | 技术选型 | 备注 |
| :--- | :--- | :--- |
| **前端 (Frontend)** | **Nuxt 4 (Vue 3)** | SSR/CSR 混合渲染，Pinia 状态管理 |
| **后端 (Backend)** | **FastAPI (Python)** | 高性能异步框架，适配 Nuxt useFetch |
| **核心 AI** | **DeepSeek** | 大语言模型推理 (API 接入) |
| **本地多模态** | **OpenAI Whisper + YOLOv8** | 语音转写与姿态分析 |
| **向量数据库** | **FAISS** | 本地 RAG 知识库检索 |

## 📂 目录结构 (Directory Structure)

```text
.
├── start.bat / start.sh      # 一键启动脚本（自动检测并安装依赖，支持双模式）
├── 微课系统/
│   ├── frontend/             # Nuxt 4 前端项目
│   │   ├── app/pages/        # 页面逻辑（首页分析 / 苏格拉底对话）
│   │   ├── app/components/   # Nuxt UI 组件
│   │   ├── app/composables/  # 状态与逻辑（SSE 流式、报告导出）
│   │   └── app/data/         # 演示模式数据 + 本地模拟对话引擎
│   ├── backend/              # FastAPI 后端项目
│   │   ├── core/             # Whisper / YOLOv8 / RAG / 多智能体逻辑
│   │   ├── main.py           # 完整版服务入口（端口 8000）
│   │   ├── trial_chat_server.py  # 体验版轻量对话后端（仅需少量依赖）
│   │   ├── requirements.txt      # 完整版后端依赖
│   │   ├── requirements-trial.txt # 体验版轻量依赖
│   │   ├── .env.example      # 复制为 .env 并填入 DEEPSEEK_API_KEY
│   │   └── data/             # 评价标准等本地数据
│   └── data/                 # 知识库（课标/标准）
└── 使用说明书.md              # 详细图文使用说明（含评委演示指南）
```

## 🚀 快速开始 (Quick Start)

### 方式一：一键启动（推荐）

```bash
# Windows
双击 start.bat 或 启动学思践悟.bat

# macOS
双击 启动学思践悟.command
```

脚本会自动检测并安装全部依赖（Python / Node.js / FFmpeg / 前后端包），并弹出**双模式选择菜单**：

| 模式 | 说明 | 适用场景 |
| :--- | :--- | :--- |
| **① 体验版** | 前端界面 + 演示分析 + 真实 AI 对话 | 快速演示、界面展示 |
| **② 完整版** | 上传视频 → 真实转写/姿态分析/AI 点评 | 完整功能演示 |

### 方式二：手动部署

```bash
# 1. 配置 API Key
cp 微课系统/backend/.env.example 微课系统/backend/.env
# 编辑 .env，填入 DEEPSEEK_API_KEY=你的key

# 2. 完整版后端
cd 微课系统/backend
pip install -r requirements.txt
python main.py

# 3. 体验版轻量后端（可选，仅需少量依赖）
pip install -r requirements-trial.txt
python trial_chat_server.py

# 4. 前端
cd 微课系统/frontend
npm install
npm run dev
```

访问 `http://localhost:3000`

## 🔑 API Key 配置

1. 在 [DeepSeek 开放平台](https://platform.deepseek.com/api_keys) 获取 API Key
2. 复制 `微课系统/backend/.env.example` 为 `.env`
3. 将 `DEEPSEEK_API_KEY=your_deepseek_api_key_here` 替换为你的 Key

> ⚠️ `.env` 已被 `.gitignore` 排除，请勿将真实 API Key 提交到仓库。

## 📄 许可证 / 说明

本项目为教育教学实训用途的开源项目。使用 DeepSeek API 会产生费用，请自行管理密钥。

## 🤝 团队分工 (Teamwork)

| 角色 | 成员 | 核心职责 |
| --- | --- | --- |
| **后端负责人** | **@LZZZZLLZL** | **架构总师**。负责 FastAPI 框架、Whisper 解析、RAG 构建。 |
| **前端负责人** | **@ph、@yjb** | **交互总师**。负责 Nuxt 4 架构、Pinia 状态、数据可视化。 |
