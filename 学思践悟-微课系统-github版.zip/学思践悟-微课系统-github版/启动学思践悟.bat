@echo off
chcp 65001 >nul
title 学思践悟 - 一键启动（评委版）

rem ======================================================
rem  学思践悟 AI 多模态实训系统 — 自适应启动脚本
rem  本脚本自动定位同目录下的 start.bat，解压到任意
rem  位置都能用，无需修改路径。
rem ======================================================

set "SCRIPT_DIR=%~dp0"
set "START_BAT=%SCRIPT_DIR%start.bat"

if not exist "%START_BAT%" (
    echo.
    echo   [错误] 找不到项目启动文件：%START_BAT%
    echo   请确保本脚本与"微课系统"文件夹在同一目录下。
    echo.
    pause
    exit /b 1
)

echo.
echo   ╔══════════════════════════════════════╗
echo   ║   🍎 学思践悟 AI 多模态实训系统     ║
echo   ║       评委演示版本 v1.0              ║
echo   ╚══════════════════════════════════════╝
echo.
echo   正在启动系统，请稍候...
echo.

cd /d "%SCRIPT_DIR%"
call "%START_BAT%"