@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title 学思践悟 AI 多模态实训系统

rem ==========================================================================
rem  学思践悟 AI 多模态实训系统 — 一键启动脚本
rem  支持两种模式：
rem    [1] 体验版：仅启动前端界面（演示模式），1-2 分钟即可开始演示
rem    [2] 完整版：自动检测并安装全部依赖（Python/Node/FFmpeg/后端包/前端包）
rem  适用于 Windows 10/11（需要联网）
rem ==========================================================================

set "ROOT_DIR=%~dp0"
set "BACKEND_DIR=%ROOT_DIR%微课系统\backend"
set "FRONTEND_DIR=%ROOT_DIR%微课系统\frontend"

echo.
echo   ============================================
echo     学思践悟 AI 多模态实训系统
echo   ============================================
echo.

rem ==========================================================================
rem 模式选择
rem ==========================================================================
echo   ┌─────────────────────────────────────────────┐
echo   │  请选择启动模式：                            │
echo   │                                             │
echo   │   [1] 体验版 · 快速演示（推荐）              │
echo   │       前端界面 + 真实 AI 对话，约 1-2 分钟   │
echo   │       点击"演示模式"查看全部功能             │
echo   │                                             │
echo   │   [2] 完整版 · 真实视频分析                  │
echo   │       自动安装 Python/FFmpeg/AI 依赖         │
echo   │       可上传视频进行真实分析（首次约10-20分）│
echo   └─────────────────────────────────────────────┘
echo.
set /p "MODE=  请输入 1 或 2（直接回车默认 1）："
if not defined MODE set "MODE=1"
echo.

if "!MODE!"=="2" goto :FULL_MODE
goto :TRIAL_MODE

rem ==========================================================================
rem ==================== 体验版模式（前端 + 轻量 AI 对话） ====================
rem ==========================================================================
:TRIAL_MODE
echo   [体验版] 正在准备前端界面 + AI 对话后端...
echo.

rem ---------- 检测 Node.js ----------
echo   [检测] Node.js...
set "NODE_OK="
where node >nul 2>nul && set "NODE_OK=1"
if defined NODE_OK (
    echo     ✓ Node.js 已就绪
) else (
    echo     ✗ 未检测到 Node.js，尝试自动安装...
    winget install --id OpenJS.NodeJS.LTS -e --source winget --silent --accept-package-agreements --accept-source-agreements >nul 2>nul
    where node >nul 2>nul && set "NODE_OK=1"
    if defined NODE_OK (
        echo     ✓ Node.js 自动安装成功
    ) else (
        echo     [错误] Node.js 安装失败，请手动安装：https://nodejs.org/
        pause
        exit /b 1
    )
)

rem ---------- 检测 Python（轻量对话后端需要） ----------
echo   [检测] Python...
set "PYTHON="
where python >nul 2>nul && set "PYTHON=python"
if not defined PYTHON ( where py >nul 2>nul && set "PYTHON=py" )
if not defined PYTHON ( where python3 >nul 2>nul && set "PYTHON=python3" )

if not defined PYTHON (
    echo     ✗ 未检测到 Python，尝试用 winget 自动安装...
    winget install --id Python.Python.3.11 -e --source winget --silent --accept-package-agreements --accept-source-agreements >nul 2>nul
    where python >nul 2>nul && set "PYTHON=python"
    if not defined PYTHON (
        for /d %%p in ("%LOCALAPPDATA%\Programs\Python\Python*") do (
            if exist "%%p\python.exe" set "PYTHON=%%p\python.exe"
        )
    )
    if defined PYTHON (
        echo     ✓ Python 自动安装成功
    ) else (
        echo     ⚠ Python 安装失败，体验版将运行"纯界面模式"（对话为本地模拟）
    )
)

rem ---------- 安装轻量后端依赖 ----------
if defined PYTHON (
    echo   [检测] 轻量对话后端依赖...
    "!PYTHON!" -c "import fastapi, openai" >nul 2>nul
    if errorlevel 1 (
        echo     ✗ 轻量后端依赖未安装，正在安装 (pip install -r requirements-trial.txt)...
        pushd "%BACKEND_DIR%"
        "!PYTHON!" -m pip install -r requirements-trial.txt
        set "PIP_OK=!ERRORLEVEL!"
        popd
        if not "!PIP_OK!"=="0" (
            echo     ⚠ 轻量后端依赖安装失败，体验版将运行"纯界面模式"（对话为本地模拟）
            set "PYTHON="
        ) else (
            echo     ✓ 轻量后端依赖安装完成
        )
    ) else (
        echo     ✓ 轻量后端依赖已就绪
    )
)

rem ---------- 检测前端依赖 ----------
echo   [检测] 前端 npm 依赖...
if not exist "%FRONTEND_DIR%\node_modules" (
    echo     ✗ 前端依赖未安装，正在安装 (npm install)...
    pushd "%FRONTEND_DIR%"
    call npm install
    set "NPM_OK=!ERRORLEVEL!"
    popd
    if not "!NPM_OK!"=="0" (
        echo     [错误] 前端依赖安装失败，请检查网络后重试
        pause
        exit /b 1
    )
    echo     ✓ 前端依赖安装完成
) else (
    echo     ✓ 前端依赖已就绪
)

rem ---------- 启动轻量对话后端（端口 8000） ----------
if defined PYTHON (
    echo.
    echo   [启动] 轻量 AI 对话后端 (FastAPI :8000)...
    start "学思践悟-对话后端" /D "%BACKEND_DIR%" cmd /k ""!PYTHON!" trial_chat_server.py"
    ping -n 4 127.0.0.1 >nul
)

rem ---------- 启动前端 ----------
echo.
echo   [启动] 前端界面 (Nuxt :3000)...
start "学思践悟-前端" /D "%FRONTEND_DIR%" cmd /k "npm run dev"
ping -n 5 127.0.0.1 >nul
start http://localhost:3000

echo.
echo   ============================================
echo   体验版启动完成！
echo     前端： http://localhost:3000
echo   ============================================
echo   💡 演示提示：
echo      1. 首页点击 "演示模式" 按钮 → 查看完整分析界面
echo      2. 分析结果中点 "开始对话" → 体验 AI 苏格拉底式对话
echo         （若检测到 DeepSeek Key 则为真实 AI 对话，
echo            否则自动切换为内置模拟对话）
echo      3. 点 "导出报告" → 下载分析报告 HTML
echo   ⚠ 体验版不做真实视频分析；如需上传视频分析，
echo      请关闭本窗口后重新启动并选择"完整版"。
echo   关闭服务窗口即可停止系统
echo.
pause
exit /b 0

rem ==========================================================================
rem ==================== 完整版模式（全部依赖） ====================
rem ==========================================================================
:FULL_MODE
echo   [完整版] 自动检测并安装全部依赖...
echo.

rem ---------- [1/6] 检查 .env ----------
if not exist "%BACKEND_DIR%\.env" (
    echo   [!] 未找到 backend\.env 文件，后端 AI 功能将受限
    echo       请创建 %BACKEND_DIR%\.env 并填入：
    echo       DEEPSEEK_API_KEY=你的key
    echo       获取 Key： https://platform.deepseek.com/api_keys
    echo.
    set /p "CONTINUE=  是否继续启动？（演示模式仍可用） [Y/N]: "
    if /I not "!CONTINUE!"=="Y" exit /b 1
)

rem ---------- [2/6] 检测 Python 3.9+ ----------
echo.
echo   [2/6] 检测 Python...
set "PYTHON="
where python >nul 2>nul && set "PYTHON=python"
if not defined PYTHON ( where py >nul 2>nul && set "PYTHON=py" )
if not defined PYTHON ( where python3 >nul 2>nul && set "PYTHON=python3" )

if defined PYTHON (
    for /f "tokens=2 delims= " %%v in ('"!PYTHON!" --version 2^>^&1') do set "PYVER=%%v"
    for /f "tokens=1,2 delims=." %%a in ("!PYVER!") do set "PYMAJOR=%%a" & set "PYMINOR=%%b"
    set "PYOK=1"
    if !PYMAJOR! LSS 3 set "PYOK=0"
    if !PYMAJOR!==3 if !PYMINOR! LSS 9 set "PYOK=0"
    if "!PYOK!"=="1" (
        echo     ✓ Python !PYVER! 已就绪
    ) else (
        echo     ⚠ Python 版本过低 (!PYVER!)，需要 3.9+，尝试自动升级安装...
        set "PYTHON="
    )
)

if not defined PYTHON (
    echo     ✗ 未检测到可用 Python，尝试用 winget 自动安装 Python 3.11...
    winget install --id Python.Python.3.11 -e --source winget --silent --accept-package-agreements --accept-source-agreements >nul 2>nul
    rem winget 安装后尝试定位（PATH 可能未刷新，需搜索安装目录）
    where python >nul 2>nul && set "PYTHON=python"
    if not defined PYTHON (
        for /d %%p in ("%LOCALAPPDATA%\Programs\Python\Python*") do (
            if exist "%%p\python.exe" set "PYTHON=%%p\python.exe"
        )
    )
    if defined PYTHON (
        echo     ✓ Python 自动安装成功
    ) else (
        echo     [错误] Python 自动安装失败
        echo     请手动安装 Python 3.9+（务必勾选 "Add Python to PATH"）：
        echo     https://www.python.org/downloads/
        echo     安装完成后重新双击本脚本即可。
        pause
        exit /b 1
    )
)

rem ---------- [3/6] 检测 Node.js 18+ ----------
echo.
echo   [3/6] 检测 Node.js...
set "NODE_OK="
where node >nul 2>nul && set "NODE_OK=1"
if defined NODE_OK (
    set "NODEV="
    for /f "delims=" %%n in ('node --version 2^>^&1') do set "NODEV=%%n"
    set "NODEV=!NODEV:v=!"
    for /f "tokens=1 delims=." %%n in ("!NODEV!") do set "NODEMAJOR=%%n"
    if !NODEMAJOR! GEQ 18 (
        echo     ✓ Node.js !NODEV! 已就绪
    ) else (
        echo     ⚠ Node.js 版本过低，尝试自动升级安装...
        set "NODE_OK="
    )
)

if not defined NODE_OK (
    echo     ✗ 未检测到可用 Node.js，尝试用 winget 自动安装 Node.js 20 LTS...
    winget install --id OpenJS.NodeJS.LTS -e --source winget --silent --accept-package-agreements --accept-source-agreements >nul 2>nul
    where node >nul 2>nul && set "NODE_OK=1"
    if defined NODE_OK (
        echo     ✓ Node.js 自动安装成功
    ) else (
        echo     [错误] Node.js 自动安装失败
        echo     请手动安装 Node.js 18+： https://nodejs.org/
        echo     安装完成后重新双击本脚本即可。
        pause
        exit /b 1
    )
)

rem ---------- [4/6] 检测 FFmpeg ----------
echo.
echo   [4/6] 检测 FFmpeg...
where ffmpeg >nul 2>nul
if not errorlevel 1 (
    echo     ✓ FFmpeg 已就绪
) else (
    echo     ✗ 未检测到 FFmpeg，尝试用 winget 自动安装...
    winget install --id Gyan.FFmpeg -e --source winget --silent --accept-package-agreements --accept-source-agreements >nul 2>nul
    where ffmpeg >nul 2>nul
    if not errorlevel 1 (
        echo     ✓ FFmpeg 自动安装成功
    ) else (
        echo     ⚠ FFmpeg 未找到（PATH 可能未刷新）
        echo     已尝试自动安装。若仍不可用，请关闭本窗口后
        echo     重新双击启动脚本（PATH 刷新后即可生效）。
        echo     提示：FFmpeg 仅真实视频分析需要，演示模式不受影响。
    )
)

rem ---------- [5/6] 检测后端 Python 依赖 ----------
echo.
echo   [5/6] 检测后端 Python 依赖...
"!PYTHON!" -c "import fastapi" >nul 2>nul
if errorlevel 1 (
    echo     ✗ 后端依赖未安装，正在自动安装 (pip install -r requirements.txt)...
    echo     首次安装约 5-10 分钟，请耐心等待（需联网）...
    pushd "%BACKEND_DIR%"
    "!PYTHON!" -m pip install -r requirements.txt
    set "PIP_OK=!ERRORLEVEL!"
    popd
    if not "!PIP_OK!"=="0" (
        echo     [错误] 后端依赖安装失败，请检查网络后重试
        pause
        exit /b 1
    )
    echo     ✓ 后端依赖安装完成
) else (
    echo     ✓ 后端依赖已就绪
)

rem ---------- [6/6] 检测前端 npm 依赖 ----------
echo.
echo   [6/6] 检测前端 npm 依赖...
if not exist "%FRONTEND_DIR%\node_modules" (
    echo     ✗ 前端依赖未安装，正在自动安装 (npm install)...
    echo     首次安装约 3-5 分钟，请耐心等待（需联网）...
    pushd "%FRONTEND_DIR%"
    call npm install
    set "NPM_OK=!ERRORLEVEL!"
    popd
    if not "!NPM_OK!"=="0" (
        echo     [错误] 前端依赖安装失败，请检查网络后重试
        pause
        exit /b 1
    )
    echo     ✓ 前端依赖安装完成
) else (
    echo     ✓ 前端依赖已就绪
)

echo.
echo   ============================================
echo   环境检查完毕，正在启动系统...
echo   ============================================
echo.

rem ---------- 启动后端 ----------
echo   [1/2] 启动后端 (FastAPI :8000)...
if not exist "%BACKEND_DIR%" (
    echo   [错误] 找不到后端目录： %BACKEND_DIR%
    pause
    exit /b 1
)

start "学思践悟-后端" /D "%BACKEND_DIR%" cmd /k "!PYTHON! main.py"

echo   等待后端就绪（首次加载模型较慢，请耐心等待）...
set "HEALTHY=0"
for /l %%i in (1,1,60) do (
    ping -n 3 127.0.0.1 >nul
    curl -s http://127.0.0.1:8000/docs >nul 2>nul
    if not errorlevel 1 (
        set "HEALTHY=1"
        goto :backend_ready
    )
)
:backend_ready
if "!HEALTHY!"=="1" (
    echo   [OK] 后端已就绪 -^> http://127.0.0.1:8000
) else (
    echo   [提示] 后端仍在加载模型，请稍候刷新页面
)

rem ---------- 启动前端 ----------
echo   [2/2] 启动前端 (Nuxt :3000)...
if not exist "%FRONTEND_DIR%" (
    echo   [错误] 找不到前端目录： %FRONTEND_DIR%
    pause
    exit /b 1
)

start "学思践悟-前端" /D "%FRONTEND_DIR%" cmd /k "npm run dev"

rem ---------- 打开浏览器 ----------
ping -n 5 127.0.0.1 >nul
start http://localhost:3000

echo.
echo   ============================================
echo   启动完成！
echo     前端： http://localhost:3000
echo     后端： http://127.0.0.1:8000/docs
echo   ============================================
echo   关闭两个服务窗口即可停止系统
echo.
pause
exit /b 0
